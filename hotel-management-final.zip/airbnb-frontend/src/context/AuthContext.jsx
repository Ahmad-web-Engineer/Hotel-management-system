import { createContext, useContext, useState } from 'react';
import {
  getToken, getUser, setToken, setUser, clearToken, clearUser,
  login as apiLogin, register as apiRegister, refreshToken as apiRefresh,
} from '../services/api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user,  setUserState]  = useState(getUser);
  const [token, setTokenState] = useState(getToken);

  const login = async ({ email, password }) => {
    // POST /auth/login → ApiResponse<LoginResponseDto { accessToken }>
    const data = await apiLogin({ email, password });

    // LoginResponseDto has exactly one field: accessToken
    const tok = data.accessToken;
    if (!tok) throw new Error('No access token received. Check server response.');

    // /auth/signup returns UserDto { id, email, name } — no role in UserDto
    // Store what we have; role comes from JWT claims
    const usr = {
      email,
      name: data.name || email.split('@')[0],
      id:   data.id   || null,
    };

    setToken(tok); setUser(usr);
    setTokenState(tok); setUserState(usr);
    return data;
  };

  const register = async ({ name, email, password }) => {
    // POST /auth/signup → ApiResponse<UserDto { id, email, name }>
    // Signup does NOT return a token — auto-login after
    const userData = await apiRegister({ name, email, password });

    // Auto-login immediately after successful signup
    return await login({ email, password });
  };

  const logout = () => {
    // No /auth/logout endpoint in backend — just clear local state
    clearToken(); clearUser();
    setTokenState(null); setUserState(null);
  };

  const refresh = async () => {
    try {
      // POST /auth/refresh → ApiResponse<LoginResponseDto { accessToken }>
      // Uses httpOnly refreshToken cookie (set automatically by browser)
      const data = await apiRefresh();
      const tok = data.accessToken;
      if (tok) { setToken(tok); setTokenState(tok); }
      return tok;
    } catch {
      logout();
      return null;
    }
  };

  return (
    <AuthContext.Provider value={{
      user, token,
      isLoggedIn: !!token,
      login, register, logout, refresh,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
