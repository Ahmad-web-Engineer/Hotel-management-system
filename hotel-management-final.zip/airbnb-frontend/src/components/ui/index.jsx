import { useState, useEffect } from 'react';

/* ── Inject global styles once ──────────────────────────────────────────── */
if (typeof document !== 'undefined' && !document.getElementById('ui-keyframes')) {
  const s = document.createElement('style');
  s.id = 'ui-keyframes';
  s.textContent = `
    @keyframes spin { to { transform: rotate(360deg); } }
    @media (max-width: 768px) {
      .modal-inner { padding: 20px !important; }
      .modal-header { padding: 18px 20px !important; }
    }
  `;
  document.head.appendChild(s);
}

/* ── Button ─────────────────────────────────────────────────────────────── */
export function Button({ children, variant = 'primary', size = 'md', loading, disabled, style = {}, ...props }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    gap: '8px', border: 'none', borderRadius: 'var(--radius)',
    fontFamily: 'inherit', fontWeight: 500, letterSpacing: '0.04em',
    transition: 'all 0.25s ease',
    cursor: loading || disabled ? 'not-allowed' : 'pointer',
    opacity: loading || disabled ? 0.65 : 1,
    whiteSpace: 'nowrap',
    WebkitTapHighlightColor: 'transparent',
  };
  const sizes = {
    sm: { padding: '8px 14px', fontSize: '12px' },
    md: { padding: '11px 22px', fontSize: '14px' },
    lg: { padding: '14px 32px', fontSize: '15px' },
  };
  const variants = {
    primary: {
      background: 'linear-gradient(135deg, var(--gold), #a8833e)',
      color: '#0a0a0f',
      boxShadow: '0 4px 20px rgba(201,169,110,0.25)',
    },
    ghost: {
      background: 'var(--glass)',
      color: 'var(--cream)',
      border: '1px solid var(--glass-border)',
    },
    danger: {
      background: 'rgba(224,82,82,0.15)',
      color: 'var(--danger)',
      border: '1px solid rgba(224,82,82,0.3)',
    },
    outline: {
      background: 'transparent',
      color: 'var(--gold)',
      border: '1px solid rgba(201,169,110,0.6)',
    },
    muted: {
      background: 'var(--glass)',
      color: 'var(--muted)',
      border: '1px solid var(--glass-border)',
    },
  };
  return (
    <button
      disabled={loading || disabled}
      style={{ ...base, ...sizes[size], ...variants[variant], ...style }}
      {...props}
    >
      {loading ? <Spinner size={13} /> : null}
      {children}
    </button>
  );
}

/* ── Input ──────────────────────────────────────────────────────────────── */
export function Input({ label, icon, error, style = {}, inputStyle = {}, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', ...style }}>
      {label && (
        <label style={{
          fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase',
          color: focused ? 'var(--gold)' : 'var(--muted)', transition: 'color 0.2s',
        }}>
          {label}
        </label>
      )}
      <div style={{ position: 'relative' }}>
        {icon && (
          <span style={{
            position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)',
            color: focused ? 'var(--gold)' : 'var(--muted)', fontSize: '15px', transition: 'color 0.2s',
            pointerEvents: 'none',
          }}>{icon}</span>
        )}
        <input
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: '100%',
            padding: icon ? '11px 13px 11px 38px' : '11px 13px',
            background: 'var(--obsidian-3)',
            border: `1px solid ${error ? 'var(--danger)' : focused ? 'rgba(201,169,110,0.6)' : 'var(--glass-border)'}`,
            borderRadius: 'var(--radius)',
            color: 'var(--cream)',
            fontSize: '14px',
            outline: 'none',
            transition: 'border-color 0.2s, box-shadow 0.2s',
            boxShadow: focused ? '0 0 0 3px rgba(201,169,110,0.08)' : 'none',
            WebkitAppearance: 'none',
            ...inputStyle,
          }}
          {...props}
        />
      </div>
      {error && <span style={{ fontSize: '12px', color: 'var(--danger)' }}>{error}</span>}
    </div>
  );
}

/* ── Select ─────────────────────────────────────────────────────────────── */
export function Select({ label, children, error, style = {}, ...props }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', ...style }}>
      {label && (
        <label style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)' }}>
          {label}
        </label>
      )}
      <select
        style={{
          padding: '11px 13px',
          background: 'var(--obsidian-3)',
          border: '1px solid var(--glass-border)',
          borderRadius: 'var(--radius)',
          color: 'var(--cream)',
          fontSize: '14px',
          outline: 'none',
          cursor: 'pointer',
          WebkitAppearance: 'none',
          width: '100%',
        }}
        {...props}
      >{children}</select>
      {error && <span style={{ fontSize: '12px', color: 'var(--danger)' }}>{error}</span>}
    </div>
  );
}

/* ── Card ───────────────────────────────────────────────────────────────── */
export function Card({ children, hover = false, style = {}, ...props }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => hover && setHovered(true)}
      onMouseLeave={() => hover && setHovered(false)}
      style={{
        background: 'var(--obsidian-2)',
        border: `1px solid ${hovered ? 'rgba(201,169,110,0.25)' : 'var(--glass-border)'}`,
        borderRadius: 'var(--radius-lg)',
        padding: '24px',
        transition: 'all 0.3s ease',
        transform: hovered ? 'translateY(-3px)' : 'none',
        boxShadow: hovered ? 'var(--shadow-gold)' : 'var(--shadow)',
        ...style,
      }}
      {...props}
    >{children}</div>
  );
}

/* ── Badge ──────────────────────────────────────────────────────────────── */
export function Badge({ children, variant = 'gold' }) {
  const variants = {
    gold:    { background: 'var(--gold-dim)',              color: 'var(--gold)',    border: '1px solid rgba(201,169,110,0.3)' },
    success: { background: 'rgba(82,196,126,0.12)',        color: 'var(--success)', border: '1px solid rgba(82,196,126,0.3)' },
    danger:  { background: 'rgba(224,82,82,0.12)',         color: 'var(--danger)',  border: '1px solid rgba(224,82,82,0.3)' },
    muted:   { background: 'var(--glass)',                 color: 'var(--muted)',   border: '1px solid var(--glass-border)' },
  };
  return (
    <span style={{
      display: 'inline-block', padding: '3px 9px', borderRadius: '20px',
      fontSize: '11px', letterSpacing: '0.07em', fontWeight: 500,
      ...(variants[variant] || variants.muted),
    }}>{children}</span>
  );
}

/* ── Spinner ────────────────────────────────────────────────────────────── */
export function Spinner({ size = 20 }) {
  return (
    <div style={{
      width: size, height: size, flexShrink: 0,
      border: `2px solid var(--glass-border)`,
      borderTopColor: 'var(--gold)',
      borderRadius: '50%',
      animation: 'spin 0.7s linear infinite',
    }} />
  );
}

/* ── Modal ──────────────────────────────────────────────────────────────── */
export function Modal({ open, onClose, title, children, width = 560 }) {
  // Lock body scroll when open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      return () => { document.body.style.overflow = ''; };
    }
  }, [open]);

  if (!open) return null;

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
        backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center',
        justifyContent: 'center', zIndex: 1000,
        padding: '16px',
        animation: 'fadeIn 0.2s ease',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--obsidian-2)',
          border: '1px solid var(--glass-border)',
          borderRadius: 'var(--radius-lg)',
          width: '100%', maxWidth: width,
          maxHeight: '92dvh', overflowY: 'auto',
          animation: 'fadeUp 0.25s ease',
          boxShadow: '0 24px 80px rgba(0,0,0,0.8)',
        }}
      >
        <div
          className="modal-header"
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '22px 28px', borderBottom: '1px solid var(--glass-border)',
            position: 'sticky', top: 0, background: 'var(--obsidian-2)', zIndex: 1,
          }}
        >
          <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '22px', fontWeight: 400 }}>{title}</h3>
          <button onClick={onClose} style={{
            background: 'none', border: 'none', color: 'var(--muted)',
            fontSize: '24px', lineHeight: 1, cursor: 'pointer', padding: '0 4px',
            display: 'flex', alignItems: 'center',
          }}>×</button>
        </div>
        <div className="modal-inner" style={{ padding: '24px 28px' }}>{children}</div>
      </div>
    </div>
  );
}

/* ── GoldLine ────────────────────────────────────────────────────────────── */
export function GoldLine({ style = {} }) {
  return (
    <div style={{
      width: '40px', height: '2px',
      background: 'linear-gradient(90deg, var(--gold), transparent)',
      margin: '10px 0',
      ...style,
    }} />
  );
}

/* ── Divider ─────────────────────────────────────────────────────────────── */
export function Divider({ style = {} }) {
  return <div style={{ height: '1px', background: 'var(--glass-border)', ...style }} />;
}
