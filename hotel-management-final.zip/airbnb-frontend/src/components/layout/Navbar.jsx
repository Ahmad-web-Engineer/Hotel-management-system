import { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';

export default function Navbar({ page, setPage, isAdmin, setIsAdmin }) {
  const { user, isLoggedIn, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    setDropdownOpen(false);
    setMobileMenuOpen(false);
    setPage('home');
  };

  const nav = (p) => { setPage(p); setMobileMenuOpen(false); setDropdownOpen(false); };

  return (
    <>
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 200,
        background: 'rgba(10,10,15,0.95)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--glass-border)',
        height: 'var(--nav-h)',
        display: 'flex', alignItems: 'center',
        padding: '0 20px',
        justifyContent: 'space-between',
        gap: '12px',
      }}>
        {/* Logo */}
        <button onClick={() => nav('home')}
          style={{ background: 'none', border: 'none', display: 'flex', alignItems: 'center', gap: '9px', cursor: 'pointer', flexShrink: 0 }}>
          <div style={{
            width: '32px', height: '32px', borderRadius: '8px',
            background: 'linear-gradient(135deg, var(--gold), #a8833e)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '15px', fontWeight: 700, color: '#0a0a0f', flexShrink: 0,
          }}>H</div>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
            <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '15px', fontWeight: 600, color: 'var(--cream)', whiteSpace: 'nowrap' }}>
              Hotel Management
            </span>
            <span style={{ fontSize: '8px', letterSpacing: '0.16em', color: 'var(--gold)', textTransform: 'uppercase' }}>System</span>
          </div>
        </button>

        {/* Center links — hidden on mobile */}
        <div className="nav-center" style={{ display: 'flex', gap: '28px', alignItems: 'center' }}>
          {[{ label: 'Browse Hotels', p: 'search' }, { label: 'About', p: 'about' }].map(l => (
            <button key={l.p} onClick={() => nav(l.p)} style={{
              background: 'none', border: 'none',
              color: page === l.p ? 'var(--gold)' : 'var(--muted)',
              fontSize: '12px', letterSpacing: '0.08em', textTransform: 'uppercase',
              transition: 'color 0.2s', cursor: 'pointer', padding: '4px 0',
              borderBottom: `1px solid ${page === l.p ? 'var(--gold)' : 'transparent'}`,
            }}>{l.label}</button>
          ))}
        </div>

        {/* Right actions */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          {/* Admin — hidden on small mobile */}
          <button
            className="nav-admin-btn"
            onClick={() => { setIsAdmin(!isAdmin); nav(isAdmin ? 'home' : 'admin-hotels'); }}
            style={{
              background: isAdmin ? 'var(--gold-dim)' : 'var(--glass)',
              border: `1px solid ${isAdmin ? 'rgba(201,169,110,0.35)' : 'var(--glass-border)'}`,
              color: isAdmin ? 'var(--gold)' : 'var(--muted)',
              padding: '6px 12px', borderRadius: 'var(--radius)',
              fontSize: '11px', letterSpacing: '0.07em', textTransform: 'uppercase',
              cursor: 'pointer', whiteSpace: 'nowrap',
            }}
          >{isAdmin ? '⬡ Admin' : 'Admin'}</button>

          {isLoggedIn ? (
            <div style={{ position: 'relative' }}>
              <button onClick={() => setDropdownOpen(o => !o)} style={{
                display: 'flex', alignItems: 'center', gap: '7px',
                background: 'var(--glass)', border: '1px solid var(--glass-border)',
                borderRadius: 'var(--radius)', padding: '6px 11px',
                color: 'var(--cream)', fontSize: '13px', cursor: 'pointer',
              }}>
                <div style={{
                  width: '22px', height: '22px', borderRadius: '50%',
                  background: 'linear-gradient(135deg, var(--gold), #a8833e)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '10px', color: '#0a0a0f', fontWeight: 700, flexShrink: 0,
                }}>
                  {(user?.name || user?.email || 'U')[0].toUpperCase()}
                </div>
                <span style={{ maxWidth: '90px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'none' }}
                  className="nav-username">
                  {user?.name || user?.email}
                </span>
                <span style={{ fontSize: '9px', color: 'var(--muted)' }}>▾</span>
              </button>

              {dropdownOpen && (
                <>
                  <div onClick={() => setDropdownOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 199 }} />
                  <div style={{
                    position: 'absolute', top: 'calc(100% + 8px)', right: 0,
                    background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
                    borderRadius: 'var(--radius)', minWidth: '200px',
                    boxShadow: '0 16px 48px rgba(0,0,0,0.7)',
                    zIndex: 300, overflow: 'hidden',
                  }}>
                    <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--glass-border)', background: 'var(--glass)' }}>
                      <div style={{ fontSize: '13px', fontWeight: 500 }}>{user?.name || 'Guest'}</div>
                      <div style={{ fontSize: '11px', color: 'var(--muted)', marginTop: '2px', wordBreak: 'break-all' }}>{user?.email}</div>
                    </div>
                    {[
                      { icon: '◎', label: 'My Bookings', p: 'bookings' },
                      { icon: '♥', label: 'Saved Hotels', p: 'wishlist' },
                    ].map(item => (
                      <button key={item.p} onClick={() => { nav(item.p); setDropdownOpen(false); }}
                        style={{
                          display: 'flex', alignItems: 'center', gap: '10px',
                          width: '100%', padding: '12px 16px',
                          background: page === item.p ? 'var(--gold-dim)' : 'none',
                          border: 'none', borderBottom: '1px solid var(--glass-border)',
                          color: page === item.p ? 'var(--gold)' : 'var(--cream)',
                          fontSize: '13px', textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
                        }}
                      ><span>{item.icon}</span>{item.label}</button>
                    ))}
                    <button onClick={handleLogout} style={{
                      display: 'flex', alignItems: 'center', gap: '10px',
                      width: '100%', padding: '12px 16px',
                      background: 'none', border: 'none',
                      color: 'var(--danger)', fontSize: '13px',
                      textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
                    }}>
                      <span>↪</span> Sign Out
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <button onClick={() => nav('auth')} style={{
              background: 'linear-gradient(135deg, var(--gold), #a8833e)',
              border: 'none', color: '#0a0a0f',
              padding: '7px 16px', borderRadius: 'var(--radius)',
              fontSize: '12px', fontWeight: 600, cursor: 'pointer',
              whiteSpace: 'nowrap',
            }}>Sign In</button>
          )}

          {/* Hamburger — mobile only */}
          <button
            onClick={() => setMobileMenuOpen(o => !o)}
            style={{
              background: 'var(--glass)', border: '1px solid var(--glass-border)',
              borderRadius: 'var(--radius)', width: '36px', height: '36px',
              display: 'none', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', flexDirection: 'column', gap: '4px',
              flexShrink: 0,
            }}
            className="hamburger-btn"
            aria-label="Menu"
          >
            {[0,1,2].map(i => (
              <div key={i} style={{ width: '16px', height: '1.5px', background: 'var(--cream)', borderRadius: '2px' }} />
            ))}
          </button>
        </div>
      </nav>

      {/* Mobile slide-down menu */}
      {mobileMenuOpen && (
        <>
          <div onClick={() => setMobileMenuOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 150 }} />
          <div style={{
            position: 'fixed', top: 'var(--nav-h)', left: 0, right: 0, zIndex: 160,
            background: 'var(--obsidian-2)', borderBottom: '1px solid var(--glass-border)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.6)',
            animation: 'fadeUp 0.2s ease',
            padding: '12px 0',
          }}>
            {[
              { label: 'Browse Hotels', p: 'search' },
              { label: 'My Bookings', p: 'bookings' },
              { label: 'Saved Hotels', p: 'wishlist' },
              { label: 'About', p: 'about' },
            ].map(item => (
              <button key={item.p} onClick={() => nav(item.p)} style={{
                display: 'block', width: '100%', padding: '14px 20px',
                background: page === item.p ? 'var(--gold-dim)' : 'none',
                border: 'none', borderBottom: '1px solid var(--glass-border)',
                color: page === item.p ? 'var(--gold)' : 'var(--cream)',
                fontSize: '14px', textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
              }}>{item.label}</button>
            ))}
            {isLoggedIn ? (
              <button onClick={handleLogout} style={{
                display: 'block', width: '100%', padding: '14px 20px',
                background: 'none', border: 'none',
                color: 'var(--danger)', fontSize: '14px',
                textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
              }}>↪ Sign Out</button>
            ) : (
              <button onClick={() => nav('auth')} style={{
                display: 'block', width: '100%', padding: '14px 20px',
                background: 'none', border: 'none',
                color: 'var(--gold)', fontSize: '14px',
                textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
              }}>Sign In / Register</button>
            )}
          </div>
        </>
      )}

      {/* Mobile-specific styles */}
      <style>{`
        @media (max-width: 768px) {
          .nav-center { display: none !important; }
          .hamburger-btn { display: flex !important; }
          .nav-admin-btn { display: none !important; }
        }
        @media (min-width: 769px) {
          .hamburger-btn { display: none !important; }
          .nav-username { display: inline !important; }
        }
      `}</style>
    </>
  );
}
