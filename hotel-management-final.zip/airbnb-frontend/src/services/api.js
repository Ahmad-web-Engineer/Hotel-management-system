// ════════════════════════════════════════════════════════════════════════════
// API Service — aligned 100% to actual Spring Boot backend
// Repo: taha-javed-dev/airBnb-clone-project
// ════════════════════════════════════════════════════════════════════════════

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

// ── Token helpers ──────────────────────────────────────────────────────────
export const getToken   = () => localStorage.getItem('hms_token');
export const setToken   = (t) => localStorage.setItem('hms_token', t);
export const clearToken = () => localStorage.removeItem('hms_token');
export const getUser    = () => {
  try { return JSON.parse(localStorage.getItem('hms_user') || 'null'); }
  catch { return null; }
};
export const setUser    = (u) => localStorage.setItem('hms_user', JSON.stringify(u));
export const clearUser  = () => localStorage.removeItem('hms_user');

// ── Core fetch wrapper ─────────────────────────────────────────────────────
// GlobalResponseHandler wraps ALL responses in: { data, error, timeStamp }
// Exception: /auth endpoints return raw ResponseEntity (not wrapped)
async function request(path, options = {}, raw = false) {
  const token = getToken();
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
    ...options,
  });

  // 204 No Content — deleteHotel, activateHotel, deleteRoom return Void
  if (res.status === 204) return null;

  let json;
  try { json = await res.json(); } catch { json = {}; }

  if (!res.ok) {
    // Error shape: ApiResponse { error: { message, subErrors } }
    const msg = json?.error?.message || json?.message || json?.error || 'Request failed';
    throw new Error(msg);
  }

  // raw=true → endpoint returns ResponseEntity directly (not wrapped)
  // raw=false → GlobalResponseHandler wraps it: { data, error, timeStamp }
  if (raw) return json;
  return json?.data !== undefined ? json.data : json;
}

// ════════════════════════════════════════════════════════════════════════════
// AuthController  @RequestMapping("/auth")
// NOTE: Auth responses are wrapped by GlobalResponseHandler too
// ════════════════════════════════════════════════════════════════════════════

// POST /auth/signup
// Body: SignUpRequestDto { email, password, name }
// Returns: ApiResponse<UserDto> { id, email, name }
// signup returns 201 CREATED — no token, user must login after
export const register = ({ name, email, password }) =>
  request('/auth/signup', {
    method: 'POST',
    body: JSON.stringify({ name, email, password }),
  });

// POST /auth/login
// Body: LoginDto { email, password }
// Returns: ApiResponse<LoginResponseDto> { accessToken }
// Also sets httpOnly refreshToken cookie automatically
export const login = ({ email, password }) =>
  request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
    credentials: 'include', // needed to receive the refreshToken cookie
  });

// POST /auth/refresh
// No body — reads refreshToken from httpOnly cookie
// Returns: ApiResponse<LoginResponseDto> { accessToken }
export const refreshToken = () =>
  request('/auth/refresh', {
    method: 'POST',
    credentials: 'include',
  });

// ════════════════════════════════════════════════════════════════════════════
// HotelBrowseController  @RequestMapping("/hotels")
// Public endpoints — no auth needed (anyRequest().permitAll())
// ════════════════════════════════════════════════════════════════════════════

// GET /hotels/search
// Body: HotelSearchRequest { city, startDate, endDate, roomsCount, page=0, size=10 }
// Returns: ApiResponse<Page<HotelDto>>
// NOTE: Backend uses @GetMapping with @RequestBody (unusual but confirmed in code)
export const searchHotels = ({ city, startDate, endDate, roomsCount, page = 0, size = 10 }) =>
  request('/hotels/search', {
    method: 'GET',
    body: JSON.stringify({ city, startDate, endDate, roomsCount, page, size }),
  });

// GET /hotels/{hotelId}/info
// Returns: ApiResponse<HotelInfoDto> { hotel: HotelDto, rooms: List<RoomDto> }
export const getHotelInfo = (hotelId) =>
  request(`/hotels/${hotelId}/info`);

// ════════════════════════════════════════════════════════════════════════════
// HotelBookingController  @RequestMapping("/bookings")
// Requires: authenticated (any logged-in user)
// ════════════════════════════════════════════════════════════════════════════

// POST /bookings/init
// Body: BookingRequest { hotelId, roomId, checkInDate, checkOutDate, roomsCount }
// Returns: ApiResponse<BookingDto>
export const initialiseBooking = ({ hotelId, roomId, checkInDate, checkOutDate, roomsCount }) =>
  request('/bookings/init', {
    method: 'POST',
    body: JSON.stringify({ hotelId, roomId, checkInDate, checkOutDate, roomsCount }),
  });

// POST /bookings/{bookingId}/addGuests
// Body: List<GuestDto> [{ name, gender (MALE/FEMALE/OTHER), age }]
// Returns: ApiResponse<BookingDto>
export const addGuests = (bookingId, guests) =>
  request(`/bookings/${bookingId}/addGuests`, {
    method: 'POST',
    body: JSON.stringify(guests),
  });

// ════════════════════════════════════════════════════════════════════════════
// HotelController  @RequestMapping("/admin/hotels")
// Requires: ROLE_HOTEL_MANAGER  (hasRole("HOTEL_MANAGER"))
// ════════════════════════════════════════════════════════════════════════════

// POST /admin/hotels
// Body: HotelDto { name, city, photos[], amenities[], contactInfo, active }
// Returns: ApiResponse<HotelDto> — 201 CREATED
export const createHotel = (data) =>
  request('/admin/hotels', {
    method: 'POST',
    body: JSON.stringify(data),
  });

// GET /admin/hotels/{hotelId}
// Returns: ApiResponse<HotelDto>
export const getHotelById = (hotelId) =>
  request(`/admin/hotels/${hotelId}`);

// PUT /admin/hotels/{hotelId}
// Body: HotelDto
// Returns: ApiResponse<HotelDto>
export const updateHotel = (hotelId, data) =>
  request(`/admin/hotels/${hotelId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });

// DELETE /admin/hotels/{hotelId}
// Returns: 204 No Content
export const deleteHotel = (hotelId) =>
  request(`/admin/hotels/${hotelId}`, { method: 'DELETE' });

// PATCH /admin/hotels/{hotelId}  — activate hotel
// Returns: 204 No Content
export const activateHotel = (hotelId) =>
  request(`/admin/hotels/${hotelId}`, { method: 'PATCH' });

// getAllHotels — NOT in HotelController, using getHotelById per-hotel
// For the admin list we fall back to mock since no list endpoint exists
export const getAllHotels = () =>
  Promise.reject(new Error('No GET /admin/hotels list endpoint in backend'));

// ════════════════════════════════════════════════════════════════════════════
// RoomAdminController  @RequestMapping("/admin/hotels/{hotelId}/rooms")
// Requires: ROLE_HOTEL_MANAGER
// ════════════════════════════════════════════════════════════════════════════

// POST /admin/hotels/{hotelId}/rooms
// Body: RoomDto { type, basePrice, photos[], amenities[], totalCount, capacity }
// Returns: ApiResponse<RoomDto> — 201 CREATED
export const createRoom = (hotelId, data) =>
  request(`/admin/hotels/${hotelId}/rooms`, {
    method: 'POST',
    body: JSON.stringify(data),
  });

// GET /admin/hotels/{hotelId}/rooms
// Returns: ApiResponse<List<RoomDto>>
export const getAllRooms = (hotelId) =>
  request(`/admin/hotels/${hotelId}/rooms`);

// GET /admin/hotels/{hotelId}/rooms/{roomId}
// Returns: ApiResponse<RoomDto>
export const getRoomById = (hotelId, roomId) =>
  request(`/admin/hotels/${hotelId}/rooms/${roomId}`);

// DELETE /admin/hotels/{hotelId}/rooms/{roomId}
// Returns: 204 No Content
export const deleteRoom = (hotelId, roomId) =>
  request(`/admin/hotels/${hotelId}/rooms/${roomId}`, { method: 'DELETE' });
