import { useState, useEffect } from 'react';
import { createHotel, updateHotel, deleteHotel, activateHotel } from '../services/api.js';
import { Button, Input, Badge, Modal, Spinner, GoldLine } from '../components/ui/index.jsx';

function HotelForm({ initial, onSave, onClose }) {
  const [form, setForm] = useState({
    name: '', city: '', active: false, amenities: '',
    contactInfo: { address: '', phoneNumber: '', email: '', location: '' },
    ...initial,
    amenities: Array.isArray(initial?.amenities) ? initial.amenities.join(', ') : (initial?.amenities || ''),
  });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const setContact = (k, v) => setForm(p => ({ ...p, contactInfo: { ...p.contactInfo, [k]: v } }));

  const handleSubmit = async () => {
    if (!form.name.trim()) { setErr('Hotel name is required.'); return; }
    if (!form.city.trim()) { setErr('City is required.'); return; }
    setLoading(true); setErr('');
    try {
      await onSave({
        ...form,
        amenities: form.amenities.split(',').map(s => s.trim()).filter(Boolean),
      });
      onClose();
    } catch (e) { setErr(e.message); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))', gap: '12px' }}>
        <Input label="Hotel Name *" value={form.name} onChange={e => set('name', e.target.value)} placeholder="Grand Maison" />
        <Input label="City *" value={form.city} onChange={e => set('city', e.target.value)} placeholder="Paris" />
      </div>
      <Input label="Amenities (comma-separated)" value={form.amenities}
        onChange={e => set('amenities', e.target.value)} placeholder="Pool, Spa, Restaurant, Free WiFi" />

      <div style={{ borderTop: '1px solid var(--glass-border)', paddingTop: '14px' }}>
        <div style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '12px' }}>Contact Information</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <Input label="Address" value={form.contactInfo?.address || ''} onChange={e => setContact('address', e.target.value)} />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: '10px' }}>
            <Input label="Phone" value={form.contactInfo?.phoneNumber || ''} onChange={e => setContact('phoneNumber', e.target.value)} />
            <Input label="Email" type="email" value={form.contactInfo?.email || ''} onChange={e => setContact('email', e.target.value)} />
          </div>
          <Input label="Location / Map Link" value={form.contactInfo?.location || ''} onChange={e => setContact('location', e.target.value)} />
        </div>
      </div>

      {err && <div style={{ padding: '10px 13px', background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.25)', borderRadius: 'var(--radius)', fontSize: '13px', color: 'var(--danger)' }}>⚠ {err}</div>}

      <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', paddingTop: '4px' }}>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} loading={loading}>{initial ? 'Save Changes' : 'Create Hotel'}</Button>
      </div>
    </div>
  );
}

export default function AdminHotelsPage({ setPage, setAdminHotelContext }) {
  const [hotels, setHotels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null);
  const [editHotel, setEditHotel] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [actionLoading, setActionLoading] = useState(null);

  // NOTE: Backend has no GET /admin/hotels list endpoint.
  // Hotels are loaded from local state after create/update.
  // Add GET /admin/hotels to HotelController to enable persistence.
  useEffect(() => {
    setHotels(getMockAdminHotels());
    setLoading(false);
  }, []);

  const handleCreate = async (data) => {
    try {
      const created = await createHotel(data);
      setHotels(h => [...h, { ...data, ...created, id: created.id || Date.now() }]);
    } catch {
      setHotels(h => [...h, { ...data, id: Date.now(), active: false }]);
    }
  };

  const handleUpdate = async (data) => {
    try {
      const updated = await updateHotel(editHotel.id, data);
      setHotels(h => h.map(x => x.id === editHotel.id ? { ...x, ...updated } : x));
    } catch {
      setHotels(h => h.map(x => x.id === editHotel.id ? { ...x, ...data } : x));
    }
  };

  const handleDelete = async (hotel) => {
    setActionLoading(hotel.id + '-del');
    try { await deleteHotel(hotel.id); } catch {}
    setHotels(h => h.filter(x => x.id !== hotel.id));
    setConfirmDelete(null);
    setActionLoading(null);
  };

  const handleActivate = async (hotel) => {
    setActionLoading(hotel.id + '-act');
    try { await activateHotel(hotel.id); } catch {}
    setHotels(h => h.map(x => x.id === hotel.id ? { ...x, active: true } : x));
    setActionLoading(null);
  };

  const goToRooms = (hotel) => { setAdminHotelContext(hotel); setPage('admin-rooms'); };

  return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: 'clamp(24px,5vw,48px) 20px' }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '32px', gap: '16px', flexWrap: 'wrap' }}>
          <div>
            <GoldLine />
            <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(28px,5vw,44px)', fontWeight: 300 }}>Hotel Management</h1>
            <p style={{ color: 'var(--muted)', fontSize: '13px', marginTop: '4px' }}>
              {hotels.length} propert{hotels.length !== 1 ? 'ies' : 'y'} registered
            </p>
          </div>
          <Button onClick={() => setModal('create')}>+ New Hotel</Button>
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}><Spinner size={36} /></div>
        ) : hotels.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '44px', opacity: 0.15, marginBottom: '14px' }}>◈</div>
            <p style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px', marginBottom: '16px' }}>No hotels yet</p>
            <Button onClick={() => setModal('create')}>Create your first hotel</Button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {hotels.map(hotel => (
              <div key={hotel.id} style={{
                background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
                borderRadius: 'var(--radius-lg)', padding: '16px 18px',
                transition: 'border-color 0.2s',
              }}
                onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(201,169,110,0.2)'}
                onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--glass-border)'}
              >
                {/* Top: name + badge + actions */}
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', flexWrap: 'wrap' }}>
                  {/* Icon */}
                  <div style={{
                    width: '44px', height: '44px', borderRadius: '10px', flexShrink: 0,
                    background: 'var(--gold-dim)', border: '1px solid rgba(201,169,110,0.2)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '18px', color: 'var(--gold)',
                  }}>◈</div>

                  {/* Info */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', marginBottom: '3px' }}>
                      <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px' }}>{hotel.name}</span>
                      {hotel.active ? <Badge variant="success">Active</Badge> : <Badge variant="muted">Inactive</Badge>}
                    </div>
                    <div style={{ display: 'flex', gap: '14px', color: 'var(--muted)', fontSize: '12px', flexWrap: 'wrap' }}>
                      <span>◎ {hotel.city}</span>
                      {hotel.amenities?.length > 0 && <span>✦ {hotel.amenities.slice(0,3).join(' · ')}</span>}
                      {hotel.contactInfo?.email && <span style={{ wordBreak: 'break-all' }}>◉ {hotel.contactInfo.email}</span>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="admin-actions" style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', flexShrink: 0 }}>
                    <button onClick={() => goToRooms(hotel)} style={{
                      background: 'var(--glass)', border: '1px solid var(--glass-border)',
                      borderRadius: 'var(--radius)', padding: '7px 12px', color: 'var(--cream)',
                      fontSize: '12px', cursor: 'pointer', whiteSpace: 'nowrap',
                    }}>Rooms</button>

                    {!hotel.active && (
                      <button onClick={() => handleActivate(hotel)}
                        disabled={actionLoading === hotel.id + '-act'}
                        style={{ background: 'rgba(82,196,126,0.08)', border: '1px solid rgba(82,196,126,0.25)', borderRadius: 'var(--radius)', padding: '7px 12px', color: 'var(--success)', fontSize: '12px', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                        {actionLoading === hotel.id + '-act' ? '…' : 'Activate'}
                      </button>
                    )}

                    <button onClick={() => { setEditHotel(hotel); setModal('edit'); }} style={{ background: 'var(--glass)', border: '1px solid var(--glass-border)', borderRadius: 'var(--radius)', padding: '7px 12px', color: 'var(--cream)', fontSize: '12px', cursor: 'pointer' }}>
                      Edit
                    </button>

                    <button onClick={() => setConfirmDelete(hotel)} style={{ background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.2)', borderRadius: 'var(--radius)', padding: '7px 12px', color: 'var(--danger)', fontSize: '12px', cursor: 'pointer' }}>
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal open={modal === 'create'} onClose={() => setModal(null)} title="New Hotel" width={600}>
        <HotelForm onSave={handleCreate} onClose={() => setModal(null)} />
      </Modal>

      <Modal open={modal === 'edit'} onClose={() => { setModal(null); setEditHotel(null); }} title="Edit Hotel" width={600}>
        {editHotel && <HotelForm initial={editHotel} onSave={handleUpdate} onClose={() => { setModal(null); setEditHotel(null); }} />}
      </Modal>

      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Hotel" width={400}>
        <p style={{ color: 'var(--muted)', lineHeight: 1.7, marginBottom: '20px' }}>
          Delete <strong style={{ color: 'var(--cream)' }}>{confirmDelete?.name}</strong>? This also removes all rooms and inventory. This cannot be undone.
        </p>
        <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
          <Button variant="ghost" onClick={() => setConfirmDelete(null)}>Cancel</Button>
          <Button variant="danger" onClick={() => handleDelete(confirmDelete)}
            loading={actionLoading === confirmDelete?.id + '-del'}>
            Delete Hotel
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function getMockAdminHotels() {
  return [
    { id: 1, name: 'Grand Maison', city: 'Paris', active: true, amenities: ['Pool', 'Spa', 'Restaurant'], contactInfo: { address: '12 Rue de Rivoli', email: 'contact@grandmaison.fr', phoneNumber: '+33 1 23 45 67' } },
    { id: 2, name: 'Villa Obscura', city: 'Rome', active: false, amenities: ['Free WiFi', 'Gym'], contactInfo: { address: 'Via del Corso 45', email: 'info@villaobscura.it' } },
    { id: 3, name: 'The Meridian', city: 'London', active: true, amenities: ['Pool', 'Restaurant', 'Free WiFi'], contactInfo: { address: '1 Mayfair Square', email: 'reservations@meridian.co.uk' } },
  ];
}
