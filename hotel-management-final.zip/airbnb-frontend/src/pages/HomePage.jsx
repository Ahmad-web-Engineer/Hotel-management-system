import { useState } from 'react';
import { Button, Input, GoldLine } from '../components/ui/index.jsx';

export default function HomePage({ setPage, setSearchParams }) {
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  const [form, setForm] = useState({
    city: '',
    startDate: today,
    endDate: tomorrow,
    roomsCount: 1,
  });

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchParams(form);
    setPage('search');
  };

  const destinations = ['Santorini', 'Kyoto', 'Amalfi', 'Marrakech', 'Bali'];

  return (
    <div style={{ minHeight: '100vh' }}>

      {/* ── Hero ── */}
      <div style={{
        position: 'relative', minHeight: '100vh',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        overflow: 'hidden',
      }}>
        {/* Background mesh */}
        <div style={{
          position: 'absolute', inset: 0,
          background: `
            radial-gradient(ellipse 80% 60% at 20% 40%, rgba(201,169,110,0.07) 0%, transparent 60%),
            radial-gradient(ellipse 60% 80% at 80% 20%, rgba(201,169,110,0.05) 0%, transparent 50%),
            radial-gradient(ellipse 40% 40% at 60% 80%, rgba(201,169,110,0.03) 0%, transparent 50%)
          `,
        }} />

        {/* Decorative grid lines */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.03,
          backgroundImage: 'linear-gradient(var(--glass-border) 1px, transparent 1px), linear-gradient(90deg, var(--glass-border) 1px, transparent 1px)',
          backgroundSize: '80px 80px',
        }} />

        {/* Large decorative number */}
        <div style={{
          position: 'absolute', right: '-2%', top: '10%',
          fontFamily: 'Cormorant Garamond', fontSize: 'clamp(200px, 25vw, 380px)',
          fontWeight: 300, color: 'rgba(201,169,110,0.04)',
          lineHeight: 1, userSelect: 'none', pointerEvents: 'none',
          letterSpacing: '-0.05em',
        }}>HMS</div>

        <div style={{
          position: 'relative', zIndex: 1,
          textAlign: 'center', padding: '120px 20px 60px',
          maxWidth: '800px', margin: '0 auto',
        }}>
          {/* Eyebrow */}
          <div className="fade-up" style={{
            display: 'inline-flex', alignItems: 'center', gap: '12px',
            marginBottom: '28px',
          }}>
            <div style={{ width: '32px', height: '1px', background: 'var(--gold)' }} />
            <span style={{
              fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase',
              color: 'var(--gold)', fontWeight: 500,
            }}>Premier Hotel Management System</span>
            <div style={{ width: '32px', height: '1px', background: 'var(--gold)' }} />
          </div>

          {/* Headline */}
          <h1 className="fade-up fade-up-1" style={{
            fontFamily: 'Cormorant Garamond', fontSize: 'clamp(48px, 8vw, 96px)',
            fontWeight: 300, lineHeight: 1.05, marginBottom: '24px', color: 'var(--cream)',
          }}>
            Find Your Perfect<br />
            <em style={{ color: "var(--gold)", fontStyle: "italic" }}>Hotel</em> Experience
          </h1>

          <p className="fade-up fade-up-2" style={{
            color: 'var(--muted)', fontSize: '16px', maxWidth: '460px',
            margin: '0 auto 48px', lineHeight: 1.7,
          }}>
            Browse and book rooms across our curated portfolio of hotels. Instant confirmation, transparent pricing, seamless management.
          </p>

          {/* Search card */}
          <form className="fade-up fade-up-3" onSubmit={handleSearch} style={{
            background: 'rgba(17,17,24,0.9)',
            backdropFilter: 'blur(20px)',
            border: '1px solid var(--glass-border)',
            borderRadius: '20px',
            padding: '28px',
            boxShadow: '0 24px 80px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.05)',
          }}>
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr 1fr auto',
              gap: '16px', alignItems: 'end',
            }}>
              <Input
                label="Destination"
                icon="◎"
                placeholder="City or region"
                value={form.city}
                onChange={e => set('city', e.target.value)}
                required
              />
              <Input
                label="Check In"
                icon="◷"
                type="date"
                value={form.startDate}
                onChange={e => set('startDate', e.target.value)}
                required
              />
              <Input
                label="Check Out"
                icon="◷"
                type="date"
                value={form.endDate}
                onChange={e => set('endDate', e.target.value)}
                required
              />
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <label style={{ fontSize: '11px', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)' }}>Rooms</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <button type="button" onClick={() => set('roomsCount', Math.max(1, form.roomsCount - 1))}
                    style={{ width: 38, height: 44, background: 'var(--glass)', border: '1px solid var(--glass-border)', borderRadius: 8, color: 'var(--cream)', fontSize: 18, cursor: 'pointer' }}>−</button>
                  <span style={{ width: 24, textAlign: 'center', fontFamily: 'Cormorant Garamond', fontSize: 20 }}>{form.roomsCount}</span>
                  <button type="button" onClick={() => set('roomsCount', form.roomsCount + 1)}
                    style={{ width: 38, height: 44, background: 'var(--glass)', border: '1px solid var(--glass-border)', borderRadius: 8, color: 'var(--cream)', fontSize: 18, cursor: 'pointer' }}>+</button>
                </div>
              </div>
            </div>

            <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'center' }}>
              <Button type="submit" size="lg" style={{ width: '100%', maxWidth: '260px' }}>
                ✦ Search Hotels
              </Button>
            </div>
          </form>

          {/* Quick destinations */}
          <div className="fade-up fade-up-4" style={{ marginTop: '28px', display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '12px', color: 'var(--muted)', alignSelf: 'center' }}>Popular:</span>
            {destinations.map(d => (
              <button key={d} onClick={() => { set('city', d); }}
                style={{
                  background: 'var(--glass)', border: '1px solid var(--glass-border)',
                  borderRadius: '20px', padding: '5px 14px', fontSize: '12px',
                  color: 'var(--cream)', cursor: 'pointer', transition: 'all 0.2s',
                }}
                onMouseEnter={e => { e.target.style.borderColor = 'rgba(201,169,110,0.4)'; e.target.style.color = 'var(--gold)'; }}
                onMouseLeave={e => { e.target.style.borderColor = 'var(--glass-border)'; e.target.style.color = 'var(--cream)'; }}
              >{d}</button>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{
          position: 'absolute', bottom: '40px', left: '50%', transform: 'translateX(-50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px',
          color: 'var(--muted)', fontSize: '11px', letterSpacing: '0.15em',
          animation: 'fadeIn 1s ease 1s both',
        }}>
          <span>SCROLL</span>
          <div style={{
            width: '1px', height: '48px',
            background: 'linear-gradient(to bottom, var(--gold), transparent)',
            animation: 'fadeUp 1.5s ease infinite',
          }} />
        </div>
      </div>

      {/* ── Features section ── */}
      <section style={{ padding: '100px 40px', maxWidth: '1100px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '64px' }}>
          <GoldLine style={{ margin: '0 auto 16px' }} />
          <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: '48px', fontWeight: 300 }}>
            Why Choose Our System
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
          {[
            { icon: '◈', title: 'Hotel Directory', desc: 'Browse our complete portfolio of hotels. Filter by city, dates, and room type.' },
            { icon: '◎', title: 'Dynamic Pricing', desc: 'Prices update in real-time based on demand, season, and inventory — always transparent.' },
            { icon: '◇', title: 'Full Booking Control', desc: 'Reserve instantly, manage guests, view history, and cancel with ease.' },
          ].map((f, i) => (
            <div key={i} style={{
              background: 'var(--obsidian-2)',
              border: '1px solid var(--glass-border)',
              borderRadius: 'var(--radius-lg)',
              padding: '36px 28px',
              textAlign: 'center',
              transition: 'border-color 0.3s',
            }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(201,169,110,0.25)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--glass-border)'}
            >
              <div style={{
                fontSize: '28px', color: 'var(--gold)', marginBottom: '16px',
                display: 'flex', justifyContent: 'center',
              }}>{f.icon}</div>
              <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '24px', marginBottom: '12px' }}>{f.title}</h3>
              <p style={{ color: 'var(--muted)', fontSize: '14px', lineHeight: 1.7 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
