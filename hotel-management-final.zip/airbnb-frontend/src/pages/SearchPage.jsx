import { useState, useEffect } from 'react';
import { searchHotels } from '../services/api.js';
import { Badge, Button, Spinner, Input, GoldLine } from '../components/ui/index.jsx';

function HotelCard({ hotel, onSelect }) {
  const photos = hotel.photos?.length ? hotel.photos : [];

  return (
    <div
      onClick={() => onSelect(hotel)}
      style={{
        background: 'var(--obsidian-2)',
        border: '1px solid var(--glass-border)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        display: 'flex', flexDirection: 'column',
        WebkitTapHighlightColor: 'transparent',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.borderColor = 'rgba(201,169,110,0.35)';
        e.currentTarget.style.transform = 'translateY(-4px)';
        e.currentTarget.style.boxShadow = '0 16px 48px rgba(0,0,0,0.5)';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.borderColor = 'var(--glass-border)';
        e.currentTarget.style.transform = 'none';
        e.currentTarget.style.boxShadow = 'none';
      }}
    >
      {/* Image */}
      <div style={{
        height: '200px', background: 'var(--obsidian-3)',
        position: 'relative', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
      }}>
        {photos[0]
          ? <img src={photos[0]} alt={hotel.name}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              loading="lazy" />
          : (
            <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
              <div style={{ fontSize: '36px', marginBottom: '6px', opacity: 0.25 }}>◈</div>
              <span style={{ fontSize: '11px', letterSpacing: '0.1em', opacity: 0.5 }}>NO IMAGE</span>
            </div>
          )
        }
        {hotel.active && (
          <div style={{ position: 'absolute', top: '10px', left: '10px' }}>
            <Badge variant="success">Available</Badge>
          </div>
        )}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0, height: '60px',
          background: 'linear-gradient(to top, var(--obsidian-2), transparent)',
        }} />
      </div>

      {/* Content */}
      <div style={{ padding: '18px 18px 20px', flex: 1, display: 'flex', flexDirection: 'column' }}>
        <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '21px', fontWeight: 400, marginBottom: '5px', lineHeight: 1.2 }}>
          {hotel.name}
        </h3>
        <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginBottom: '12px' }}>
          <span style={{ fontSize: '12px', color: 'var(--gold)' }}>◎</span>
          <span style={{ fontSize: '13px', color: 'var(--muted)' }}>{hotel.city}</span>
        </div>

        {hotel.amenities?.length > 0 && (
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '14px' }}>
            {hotel.amenities.slice(0, 3).map(a => (
              <span key={a} style={{
                fontSize: '11px', color: 'var(--muted)',
                background: 'var(--glass)', border: '1px solid var(--glass-border)',
                borderRadius: '4px', padding: '2px 7px',
              }}>{a}</span>
            ))}
            {hotel.amenities.length > 3 && (
              <span style={{ fontSize: '11px', color: 'var(--muted)', padding: '2px 4px' }}>
                +{hotel.amenities.length - 3}
              </span>
            )}
          </div>
        )}

        <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          {hotel.avgPrice != null ? (
            <div>
              <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '24px', color: 'var(--gold)' }}>
                ${Number(hotel.avgPrice).toFixed(0)}
              </span>
              <span style={{ fontSize: '11px', color: 'var(--muted)' }}> /night</span>
            </div>
          ) : <span />}
          <span style={{ fontSize: '12px', color: 'var(--gold)', letterSpacing: '0.04em' }}>View →</span>
        </div>
      </div>
    </div>
  );
}

export default function SearchPage({ initialParams, setPage, setSelectedHotel }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState('');
  const [searched, setSearched] = useState(false);

  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  const [params, setParams] = useState({
    city: initialParams?.city || '',
    startDate: initialParams?.startDate || today,
    endDate:   initialParams?.endDate   || tomorrow,
    roomsCount: initialParams?.roomsCount || 1,
  });

  const set = (k, v) => setParams(p => ({ ...p, [k]: v }));

  // Validate dates: endDate must be after startDate
  const validateDates = () => {
    if (params.endDate && params.startDate && params.endDate <= params.startDate) {
      const next = new Date(params.startDate);
      next.setDate(next.getDate() + 1);
      set('endDate', next.toISOString().split('T')[0]);
    }
  };

  const doSearch = async () => {
    if (!params.city.trim()) {
      setError('Please enter a destination city.');
      return;
    }
    if (params.endDate <= params.startDate) {
      setError('Check-out must be after check-in.');
      return;
    }
    setLoading(true); setError(''); setSearched(true);
    try {
      const data = await searchHotels({ ...params, page: 0, size: 20 });
      setResults(Array.isArray(data) ? data : data.content || []);
    } catch (e) {
      setError(e.message + ' — showing demo data');
      setResults(getMockHotels(params.city));
    } finally {
      setLoading(false);
    }
  };

  // Auto-search if coming from home page with params
  useEffect(() => {
    if (initialParams?.city) doSearch();
  }, []);

  const handleSelect = (hotel) => {
    setSelectedHotel(hotel);
    setPage('hotel-detail');
  };

  const handleKey = (e) => { if (e.key === 'Enter') doSearch(); };

  return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)' }}>
      {/* Search bar */}
      <div style={{
        background: 'var(--obsidian-2)',
        borderBottom: '1px solid var(--glass-border)',
        padding: '16px 20px',
        position: 'sticky', top: 'var(--nav-h)', zIndex: 100,
      }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
          <div
            className="search-bar-grid"
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 140px 140px 80px auto',
              gap: '10px', alignItems: 'end',
            }}
          >
            <Input
              label="Destination"
              placeholder="City or region"
              value={params.city}
              onChange={e => set('city', e.target.value)}
              onKeyDown={handleKey}
              icon="◎"
            />
            <Input
              label="Check In"
              type="date"
              value={params.startDate}
              min={today}
              onChange={e => { set('startDate', e.target.value); validateDates(); }}
            />
            <Input
              label="Check Out"
              type="date"
              value={params.endDate}
              min={params.startDate || today}
              onChange={e => set('endDate', e.target.value)}
            />
            <Input
              label="Rooms"
              type="number"
              value={params.roomsCount}
              min={1} max={20}
              onChange={e => set('roomsCount', Math.max(1, +e.target.value))}
              inputStyle={{ textAlign: 'center' }}
            />
            <Button onClick={doSearch} loading={loading} style={{ alignSelf: 'flex-end', height: '44px' }}>
              Search
            </Button>
          </div>
          {error && (
            <div style={{
              marginTop: '10px', padding: '10px 14px',
              background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.2)',
              borderRadius: 'var(--radius)', fontSize: '13px', color: 'var(--danger)',
            }}>⚠ {error}</div>
          )}
        </div>
      </div>

      {/* Results */}
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '32px 20px' }}>
        {!searched && !loading ? (
          <div style={{ textAlign: 'center', padding: '80px 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '56px', opacity: 0.15, marginBottom: '16px' }}>◎</div>
            <p style={{ fontFamily: 'Cormorant Garamond', fontSize: '24px', marginBottom: '8px' }}>
              Find Your Perfect Stay
            </p>
            <p style={{ fontSize: '13px' }}>Enter a city above and tap Search</p>
          </div>
        ) : loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '80px 0' }}>
            <Spinner size={36} />
          </div>
        ) : (
          <>
            <div style={{ marginBottom: '28px' }}>
              <GoldLine />
              <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(26px,5vw,36px)', fontWeight: 300 }}>
                Hotels in {params.city}
              </h2>
              <p style={{ color: 'var(--muted)', fontSize: '13px', marginTop: '4px' }}>
                {results.length} {results.length === 1 ? 'property' : 'properties'} found
              </p>
            </div>

            {results.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
                <div style={{ fontSize: '48px', opacity: 0.2, marginBottom: '16px' }}>◎</div>
                <p style={{ fontFamily: 'Cormorant Garamond', fontSize: '22px', marginBottom: '8px' }}>No hotels found</p>
                <p style={{ fontSize: '13px' }}>Try a different city or date range</p>
              </div>
            ) : (
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(min(300px, 100%), 1fr))',
                gap: '20px',
              }}>
                {results.map((hotel, i) => (
                  <div key={hotel.id || i} className="fade-up" style={{ animationDelay: `${Math.min(i * 0.05, 0.3)}s` }}>
                    <HotelCard hotel={hotel} onSelect={handleSelect} />
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function getMockHotels(city) {
  return [
    { id: 1, name: 'Grand Maison', city, active: true, amenities: ['Pool', 'Spa', 'Restaurant'], avgPrice: 320 },
    { id: 2, name: 'Villa Obscura', city, active: true, amenities: ['Free WiFi', 'Gym'], avgPrice: 195 },
    { id: 3, name: 'The Meridian', city, active: true, amenities: ['Pool', 'Free WiFi', 'Gym'], avgPrice: 450 },
    { id: 4, name: 'Casetta Privata', city, active: false, amenities: ['Spa'], avgPrice: 270 },
    { id: 5, name: 'Hôtel du Lac', city, active: true, amenities: ['Restaurant', 'Pool', 'Gym'], avgPrice: 510 },
    { id: 6, name: 'The Black Pearl', city, active: true, amenities: ['Spa', 'Free WiFi'], avgPrice: 380 },
  ];
}
