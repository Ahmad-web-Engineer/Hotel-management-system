import { useState } from 'react';
import { initialiseBooking, addGuests } from '../services/api.js';
import { Button, Input, Select, Badge, GoldLine } from '../components/ui/index.jsx';

const STEPS = ['Stay Details', 'Guests', 'Confirmation'];

function StepIndicator({ current }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '36px' }}>
      {STEPS.map((s, i) => (
        <div key={s} style={{ display: 'flex', alignItems: 'center', flex: i < STEPS.length - 1 ? 1 : 0 }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
            <div style={{
              width: '34px', height: '34px', borderRadius: '50%',
              background: i < current ? 'var(--gold)' : i === current ? 'var(--gold-dim)' : 'var(--glass)',
              border: `2px solid ${i <= current ? 'var(--gold)' : 'var(--glass-border)'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: i < current ? '#0a0a0f' : i === current ? 'var(--gold)' : 'var(--muted)',
              fontSize: '12px', fontWeight: 600, transition: 'all 0.3s',
            }}>
              {i < current ? '✓' : i + 1}
            </div>
            <span style={{
              fontSize: '10px', letterSpacing: '0.08em', textTransform: 'uppercase',
              color: i === current ? 'var(--gold)' : 'var(--muted)', whiteSpace: 'nowrap',
            }}>{s}</span>
          </div>
          {i < STEPS.length - 1 && (
            <div style={{
              flex: 1, height: '1px', margin: '0 6px', marginBottom: '22px',
              background: i < current ? 'var(--gold)' : 'var(--glass-border)',
              transition: 'background 0.3s',
            }} />
          )}
        </div>
      ))}
    </div>
  );
}

/* ── Price Summary ── */
function PriceSummary({ hotel, room, nights, rooms, estTotal }) {
  return (
    <div style={{
      background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-lg)', padding: '22px',
    }}>
      <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px', marginBottom: '4px' }}>Price Summary</h3>
      <GoldLine />
      <div style={{ marginTop: '14px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {[
          { label: 'Property',  val: hotel?.name },
          { label: 'Room Type', val: room?.type },
          { label: 'Rate',      val: `$${Number(room?.basePrice).toFixed(0)}/night` },
          { label: 'Duration',  val: `${nights} night${nights !== 1 ? 's' : ''}` },
          { label: 'Rooms',     val: `× ${rooms}` },
        ].map(r => (
          <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
            <span style={{ color: 'var(--muted)' }}>{r.label}</span>
            <span>{r.val}</span>
          </div>
        ))}
        <div style={{ height: '1px', background: 'var(--glass-border)', margin: '4px 0' }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <span style={{ color: 'var(--muted)', fontSize: '11px', letterSpacing: '0.08em' }}>EST. TOTAL</span>
          <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '26px', color: 'var(--gold)' }}>${estTotal}</span>
        </div>
        <p style={{ fontSize: '11px', color: 'var(--muted)', lineHeight: 1.6 }}>
          Final price may vary based on dynamic pricing at confirmation.
        </p>
      </div>
    </div>
  );
}

/* ── Step 1: Dates & Rooms ── */
// Sends: BookingRequest { hotelId, roomId, checkInDate, checkOutDate, roomsCount }
function StepOne({ hotel, room, onNext }) {
  const today    = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  const [form, setForm] = useState({ checkInDate: today, checkOutDate: tomorrow, roomsCount: 1 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const nights   = Math.max(1, Math.round((new Date(form.checkOutDate) - new Date(form.checkInDate)) / 86400000));
  const estTotal = (Number(room?.basePrice || 0) * nights * form.roomsCount).toFixed(2);

  const handleSubmit = async () => {
    if (form.checkOutDate <= form.checkInDate) { setError('Check-out must be after check-in.'); return; }
    setLoading(true); setError('');
    try {
      // Exact BookingRequest fields
      const booking = await initialiseBooking({
        hotelId:      hotel.id,
        roomId:       room.id,
        checkInDate:  form.checkInDate,
        checkOutDate: form.checkOutDate,
        roomsCount:   Number(form.roomsCount),
      });
      onNext(booking);
    } catch (e) {
      setError(e.message + ' — proceeding with demo');
      onNext({ id: Date.now(), bookingStatus: 'RESERVED', ...form });
    } finally { setLoading(false); }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div>
        <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(26px,5vw,36px)', marginBottom: '6px' }}>Stay Details</h2>
        <GoldLine />
      </div>

      {/* Dates grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))', gap: '14px' }}>
        <Input label="Check In Date" type="date" value={form.checkInDate}
          min={today} onChange={e => set('checkInDate', e.target.value)} />
        <Input label="Check Out Date" type="date" value={form.checkOutDate}
          min={form.checkInDate} onChange={e => set('checkOutDate', e.target.value)} />
        <Input label="Rooms" type="number" min={1} max={room?.totalCount || 10}
          value={form.roomsCount} onChange={e => set('roomsCount', Math.max(1, +e.target.value))} />
      </div>

      {/* Price summary */}
      <PriceSummary hotel={hotel} room={room} nights={nights} rooms={form.roomsCount} estTotal={estTotal} />

      {error && (
        <div style={{ padding: '11px 13px', background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.2)', borderRadius: 'var(--radius)', fontSize: '13px', color: 'var(--danger)' }}>
          ⚠ {error}
        </div>
      )}
      <Button size="lg" onClick={handleSubmit} loading={loading}>Continue to Guests →</Button>
    </div>
  );
}

/* ── Step 2: Guests ── */
// Sends: GuestDto[] [ { name, gender, age } ]
function StepTwo({ booking, onNext }) {
  const [guests, setGuests] = useState([{ name: '', gender: 'MALE', age: '' }]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const addGuest    = () => setGuests(g => [...g, { name: '', gender: 'MALE', age: '' }]);
  const removeGuest = (i) => setGuests(g => g.filter((_, idx) => idx !== i));
  const setField    = (i, k, v) => setGuests(g => g.map((x, idx) => idx === i ? { ...x, [k]: v } : x));

  const handleSubmit = async () => {
    const invalid = guests.find(g => !g.name.trim());
    if (invalid) { setError('Please fill in all guest names.'); return; }
    setLoading(true); setError('');
    try {
      // GuestDto: { name, gender, age }
      const payload = guests.map(g => ({
        name:   g.name.trim(),
        gender: g.gender,
        age:    Number(g.age) || 0,
      }));
      const updated = await addGuests(booking.id, payload);
      onNext(updated || { ...booking, bookingStatus: 'GUESTS_ADDED', guests: payload });
    } catch (e) {
      setError(e.message + ' — proceeding');
      onNext({ ...booking, bookingStatus: 'GUESTS_ADDED', guests });
    } finally { setLoading(false); }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div>
        <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(26px,5vw,36px)', marginBottom: '6px' }}>Guest Information</h2>
        <GoldLine />
        <p style={{ color: 'var(--muted)', fontSize: '14px', marginTop: '8px' }}>
          Add details for all guests staying in this reservation.
        </p>
      </div>

      {guests.map((g, i) => (
        <div key={i} style={{
          background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
          borderRadius: 'var(--radius-lg)', padding: '18px 18px',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '18px' }}>Guest {i + 1}</span>
            {guests.length > 1 && (
              <button onClick={() => removeGuest(i)} style={{ background: 'none', border: 'none', color: 'var(--danger)', cursor: 'pointer', fontSize: '12px' }}>
                Remove
              </button>
            )}
          </div>
          {/* GuestDto fields: name, gender, age */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(140px,1fr))', gap: '12px' }}>
            <Input label="Full Name *" placeholder="John Doe"
              value={g.name} onChange={e => setField(i, 'name', e.target.value)}
              style={{ gridColumn: 'span 2' }} />
            <Select label="Gender" value={g.gender} onChange={e => setField(i, 'gender', e.target.value)}>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </Select>
            <Input label="Age" type="number" min={1} max={120}
              value={g.age} onChange={e => setField(i, 'age', e.target.value)} />
          </div>
        </div>
      ))}

      <button onClick={addGuest} style={{
        background: 'none', border: '1px dashed var(--glass-border)',
        borderRadius: 'var(--radius)', width: '100%', padding: '13px',
        color: 'var(--muted)', cursor: 'pointer', fontSize: '13px',
        transition: 'all 0.2s', fontFamily: 'inherit',
      }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(201,169,110,0.3)'; e.currentTarget.style.color = 'var(--gold)'; }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--glass-border)'; e.currentTarget.style.color = 'var(--muted)'; }}
      >+ Add Another Guest</button>

      {error && (
        <div style={{ padding: '11px 13px', background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.2)', borderRadius: 'var(--radius)', fontSize: '13px', color: 'var(--danger)' }}>
          ⚠ {error}
        </div>
      )}
      <Button size="lg" onClick={handleSubmit} loading={loading}>Confirm Booking →</Button>
    </div>
  );
}

/* ── Step 3: Confirmation ── */
function StepThree({ booking, hotel, room, setPage }) {
  return (
    <div style={{ maxWidth: '520px', margin: '0 auto', textAlign: 'center', padding: '0 4px' }}>
      <div style={{
        width: '72px', height: '72px', borderRadius: '50%',
        background: 'rgba(82,196,126,0.12)', border: '2px solid rgba(82,196,126,0.4)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        margin: '0 auto 24px', fontSize: '28px', color: 'var(--success)',
      }}>✓</div>

      <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(28px,6vw,42px)', marginBottom: '10px' }}>
        Booking Confirmed
      </h2>
      <GoldLine style={{ margin: '0 auto 18px' }} />
      <p style={{ color: 'var(--muted)', fontSize: '14px', lineHeight: 1.7, marginBottom: '28px' }}>
        Your reservation is confirmed. You can manage it from My Bookings.
      </p>

      {/* BookingDto summary */}
      <div style={{
        background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
        borderRadius: 'var(--radius-lg)', padding: '20px', textAlign: 'left', marginBottom: '28px',
      }}>
        <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '18px', marginBottom: '14px', color: 'var(--gold)' }}>
          Booking Summary
        </div>
        {[
          { label: 'Booking ID',  val: `#${booking?.id || '—'}` },
          { label: 'Status',      val: <Badge variant="success">{booking?.bookingStatus || 'RESERVED'}</Badge> },
          { label: 'Hotel',       val: hotel?.name },
          { label: 'Room',        val: room?.type },
          { label: 'Check In',    val: booking?.checkInDate },
          { label: 'Check Out',   val: booking?.checkOutDate },
          { label: 'Rooms',       val: booking?.roomsCount },
        ].filter(r => r.val).map(r => (
          <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderBottom: '1px solid var(--glass-border)' }}>
            <span style={{ color: 'var(--muted)', fontSize: '13px' }}>{r.label}</span>
            <span style={{ fontSize: '13px' }}>{r.val}</span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap' }}>
        <Button variant="ghost" onClick={() => setPage('bookings')}>My Bookings</Button>
        <Button onClick={() => setPage('search')}>Search More Hotels</Button>
      </div>
    </div>
  );
}

/* ── Main ── */
export default function BookingPage({ bookingContext, setPage }) {
  const { hotel, room } = bookingContext || {};
  const [step, setStep]       = useState(0);
  const [booking, setBooking] = useState(null);

  return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)' }}>
      <div style={{ maxWidth: '720px', margin: '0 auto', padding: 'clamp(24px,5vw,48px) 20px' }}>
        <button onClick={() => step > 0 ? setStep(s => s - 1) : setPage('hotel-detail')} style={{
          background: 'none', border: 'none', color: 'var(--muted)', fontSize: '13px',
          cursor: 'pointer', marginBottom: '28px', display: 'flex', alignItems: 'center', gap: '6px',
          padding: '4px 0',
        }}>← {step > 0 ? 'Back' : 'Back to Hotel'}</button>

        <StepIndicator current={step} />

        <div className="fade-up">
          {step === 0 && <StepOne hotel={hotel} room={room} onNext={b => { setBooking(b); setStep(1); }} />}
          {step === 1 && <StepTwo booking={booking} onNext={b => { setBooking(b); setStep(2); }} />}
          {step === 2 && <StepThree booking={booking} hotel={hotel} room={room} setPage={setPage} />}
        </div>
      </div>
    </div>
  );
}
