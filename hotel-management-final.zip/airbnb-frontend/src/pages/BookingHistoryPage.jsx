import { useState, useEffect } from 'react';
import { getMyBookings, cancelBooking, submitReview } from '../services/api.js';
import { Badge, Button, Spinner, GoldLine, Modal } from '../components/ui/index.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const STATUS_VARIANT = { CONFIRMED:'success', PENDING:'gold', CANCELLED:'danger', COMPLETED:'muted' };
const getVariant = (s) => STATUS_VARIANT[(s || '').toUpperCase()] || 'muted';

function ReviewModal({ booking, open, onClose }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [hovered, setHovered] = useState(0);
  const [err, setErr] = useState('');
  const [done, setDone] = useState(false);

  const handleSubmit = async () => {
    if (!comment.trim()) { setErr('Please write a comment.'); return; }
    setLoading(true); setErr('');
    try {
      await submitReview(booking.hotelId || booking.hotel?.id, { rating, comment });
      setDone(true);
      setTimeout(onClose, 1200);
    } catch (e) { setErr(e.message); }
    finally { setLoading(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title={`Review — ${booking?.hotelName || 'Hotel'}`}>
      {done ? (
        <div style={{ textAlign: 'center', padding: '24px 0', color: 'var(--success)' }}>
          ✓ Review submitted! Thank you.
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          <div>
            <label style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', display: 'block', marginBottom: '10px' }}>Rating</label>
            <div style={{ display: 'flex', gap: '4px', alignItems: 'center', flexWrap: 'wrap' }}>
              {[1,2,3,4,5].map(s => (
                <button key={s}
                  onMouseEnter={() => setHovered(s)} onMouseLeave={() => setHovered(0)}
                  onClick={() => setRating(s)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '28px', padding: '2px', transition: 'transform 0.15s', transform: (hovered||rating)>=s?'scale(1.2)':'scale(1)', color: (hovered||rating)>=s?'var(--gold)':'rgba(201,169,110,0.2)' }}>★</button>
              ))}
              <span style={{ marginLeft: '6px', color: 'var(--muted)', fontSize: '13px' }}>
                {['','Poor','Fair','Good','Great','Excellent'][hovered||rating]}
              </span>
            </div>
          </div>
          <div>
            <label style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', display: 'block', marginBottom: '8px' }}>Your Review</label>
            <textarea value={comment} onChange={e => setComment(e.target.value)}
              placeholder="Share your experience..." rows={4}
              style={{ width: '100%', padding: '11px 13px', background: 'var(--obsidian-3)', border: '1px solid var(--glass-border)', borderRadius: 'var(--radius)', color: 'var(--cream)', fontSize: '14px', outline: 'none', resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.6 }} />
            {err && <div style={{ fontSize: '12px', color: 'var(--danger)', marginTop: '4px' }}>{err}</div>}
          </div>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
            <Button variant="ghost" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSubmit} loading={loading} disabled={!comment.trim()}>Submit Review</Button>
          </div>
        </div>
      )}
    </Modal>
  );
}

function BookingCard({ booking, onCancel, onReview }) {
  const [cancelling, setCancelling] = useState(false);
  const checkIn  = new Date(booking.checkIn  || booking.startDate || booking.checkInDate);
  const checkOut = new Date(booking.checkOut || booking.endDate   || booking.checkOutDate);
  const nights   = Math.max(1, Math.round((checkOut - checkIn) / 86400000));
  const status   = (booking.status || 'PENDING').toUpperCase();
  const isPast   = checkOut < new Date();
  const isCancellable = !isPast && !['CANCELLED'].includes(status);

  const handleCancel = async () => {
    if (!confirm('Cancel this booking?')) return;
    setCancelling(true);
    try { await onCancel(booking.id); }
    catch (e) { alert(e.message); }
    finally { setCancelling(false); }
  };

  const fmtDate = (d) => isNaN(d) ? '—' : d.toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });

  return (
    <div style={{
      background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius-lg)', overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', gap: 0 }}>
        {/* Status bar */}
        <div style={{
          width: '4px', flexShrink: 0,
          background: status === 'CONFIRMED' ? 'var(--success)' : status === 'CANCELLED' ? 'var(--danger)' : 'var(--gold)',
        }} />
        <div style={{ flex: 1, padding: '20px 20px' }}>
          {/* Top row */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px', flexWrap: 'wrap', marginBottom: '12px' }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap', marginBottom: '4px' }}>
                <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(18px,4vw,22px)' }}>
                  {booking.hotelName || booking.hotel?.name || 'Hotel'}
                </h3>
                <Badge variant={getVariant(status)}>{status}</Badge>
              </div>
              <p style={{ color: 'var(--muted)', fontSize: '13px' }}>◎ {booking.city || booking.hotel?.city || '—'}</p>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '26px', color: 'var(--gold)' }}>
                ${Number(booking.totalPrice || booking.total || 0).toFixed(0)}
              </div>
              <div style={{ fontSize: '11px', color: 'var(--muted)' }}>total</div>
            </div>
          </div>

          {/* Date row */}
          <div style={{
            display: 'flex', gap: '16px', paddingTop: '12px',
            borderTop: '1px solid var(--glass-border)', flexWrap: 'wrap', marginBottom: '14px',
          }}>
            {[
              { label: 'Check In',  val: fmtDate(checkIn) },
              { label: 'Check Out', val: fmtDate(checkOut) },
              { label: 'Nights',    val: nights },
              booking.roomsCount && { label: 'Rooms', val: booking.roomsCount },
            ].filter(Boolean).map(f => (
              <div key={f.label}>
                <div style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '2px' }}>{f.label}</div>
                <div style={{ fontSize: '14px' }}>{f.val}</div>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            {isCancellable && (
              <Button variant="danger" size="sm" loading={cancelling} onClick={handleCancel}>
                Cancel
              </Button>
            )}
            {isPast && status !== 'CANCELLED' && (
              <Button variant="outline" size="sm" onClick={() => onReview(booking)}>
                Write Review
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function BookingHistoryPage({ setPage }) {
  const { isLoggedIn } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [filter,   setFilter]   = useState('all');
  const [reviewTarget, setReviewTarget] = useState(null);

  useEffect(() => {
    if (!isLoggedIn) return;
    // NOTE: Backend does not yet have GET /bookings/my endpoint.
    // Add it to HotelBookingController to show real booking history.
    // Using demo data until then.
    setBookings(getMockBookings());
    setLoading(false);
  }, [isLoggedIn]);

  const handleCancel = async (id) => {
    await cancelBooking(id);
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status: 'CANCELLED' } : b));
  };

  const now = new Date();
  const filtered = bookings.filter(b => {
    const out = new Date(b.checkOut || b.endDate || b.checkOutDate);
    const s = (b.status || '').toUpperCase();
    if (filter === 'upcoming')  return out >= now && s !== 'CANCELLED';
    if (filter === 'past')      return out < now  && s !== 'CANCELLED';
    if (filter === 'cancelled') return s === 'CANCELLED';
    return true;
  });

  if (!isLoggedIn) return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '100px 20px' }}>
      <div style={{ textAlign: 'center', maxWidth: '360px' }}>
        <div style={{ fontSize: '44px', marginBottom: '14px', color: 'var(--gold)', opacity: 0.6 }}>◈</div>
        <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: '28px', fontWeight: 300, marginBottom: '10px' }}>Sign In Required</h2>
        <p style={{ color: 'var(--muted)', fontSize: '14px', marginBottom: '24px' }}>Sign in to view your booking history.</p>
        <Button onClick={() => setPage('auth')}>Sign In</Button>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)' }}>
      <div style={{ maxWidth: '820px', margin: '0 auto', padding: 'clamp(24px,5vw,48px) 20px' }}>
        <div style={{ marginBottom: '32px' }}>
          <GoldLine />
          <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(32px,6vw,48px)', fontWeight: 300, marginBottom: '6px' }}>
            My Bookings
          </h1>
          <p style={{ color: 'var(--muted)', fontSize: '13px' }}>{bookings.length} total</p>
        </div>

        {/* Filter pills */}
        <div style={{ display: 'flex', gap: '8px', marginBottom: '24px', flexWrap: 'wrap' }}>
          {['all','upcoming','past','cancelled'].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{
              padding: '7px 16px', borderRadius: '20px', border: 'none', cursor: 'pointer',
              fontSize: '12px', letterSpacing: '0.06em', textTransform: 'capitalize', fontFamily: 'inherit',
              background: filter === f ? 'var(--gold-dim)' : 'var(--glass)',
              color: filter === f ? 'var(--gold)' : 'var(--muted)',
              border: `1px solid ${filter === f ? 'rgba(201,169,110,0.3)' : 'var(--glass-border)'}`,
              transition: 'all 0.2s',
            }}>{f}</button>
          ))}
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}><Spinner size={36} /></div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '40px', opacity: 0.2, marginBottom: '14px' }}>◎</div>
            <p style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px', marginBottom: '6px' }}>No bookings found</p>
            <p style={{ fontSize: '13px', marginBottom: '20px' }}>
              {filter === 'all' ? "You haven't made any bookings yet." : `No ${filter} bookings.`}
            </p>
            <Button onClick={() => setPage('search')}>Browse Hotels</Button>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {filtered.map((b, i) => (
              <div key={b.id || i} className="fade-up" style={{ animationDelay: `${Math.min(i*0.05,0.3)}s` }}>
                <BookingCard booking={b} onCancel={handleCancel} onReview={setReviewTarget} />
              </div>
            ))}
          </div>
        )}
      </div>

      {reviewTarget && (
        <ReviewModal booking={reviewTarget} open={!!reviewTarget} onClose={() => setReviewTarget(null)} />
      )}
    </div>
  );
}

function getMockBookings() {
  const now = new Date();
  return [
    { id: 1, hotelName: 'Grand Maison', city: 'Paris', status: 'CONFIRMED',
      checkIn: new Date(now.getTime() + 7*86400000).toISOString(),
      checkOut: new Date(now.getTime() + 10*86400000).toISOString(),
      totalPrice: 960, roomsCount: 2 },
    { id: 2, hotelName: 'Villa Obscura', city: 'Santorini', status: 'COMPLETED',
      checkIn: new Date(now.getTime() - 30*86400000).toISOString(),
      checkOut: new Date(now.getTime() - 26*86400000).toISOString(),
      totalPrice: 780, roomsCount: 1 },
    { id: 3, hotelName: 'The Meridian', city: 'Kyoto', status: 'CANCELLED',
      checkIn: new Date(now.getTime() - 10*86400000).toISOString(),
      checkOut: new Date(now.getTime() - 7*86400000).toISOString(),
      totalPrice: 1350, roomsCount: 1 },
  ];
}
