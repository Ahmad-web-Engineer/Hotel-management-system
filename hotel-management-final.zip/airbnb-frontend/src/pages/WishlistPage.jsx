import { useState, useEffect } from 'react';
import { getWishlist, removeFromWishlist } from '../services/api.js';
import { Button, Spinner, GoldLine } from '../components/ui/index.jsx';
import { useAuth } from '../context/AuthContext.jsx';

function WishlistCard({ hotel, onRemove, onSelect }) {
  const [removing, setRemoving] = useState(false);

  const handleRemove = async (e) => {
    e.stopPropagation();
    setRemoving(true);
    try { await onRemove(hotel.id); }
    catch (e) { alert(e.message); setRemoving(false); }
  };

  return (
    <div onClick={() => onSelect(hotel)}
      style={{
        background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
        borderRadius: 'var(--radius-lg)', overflow: 'hidden', cursor: 'pointer',
        transition: 'all 0.3s ease',
        WebkitTapHighlightColor: 'transparent',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.borderColor = 'rgba(201,169,110,0.3)';
        e.currentTarget.style.transform = 'translateY(-4px)';
        e.currentTarget.style.boxShadow = '0 16px 48px rgba(0,0,0,0.5)';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.borderColor = 'var(--glass-border)';
        e.currentTarget.style.transform = 'none';
        e.currentTarget.style.boxShadow = 'none';
      }}
    >
      {/* Image */}
      <div style={{ height: '180px', background: 'var(--obsidian-3)', position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {hotel.photos?.[0]
          ? <img src={hotel.photos[0]} alt={hotel.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} loading="lazy" />
          : <div style={{ fontSize: '36px', color: 'var(--muted)', opacity: 0.2 }}>◈</div>
        }
        {/* Remove button */}
        <button onClick={handleRemove} style={{
          position: 'absolute', top: '10px', right: '10px',
          width: '34px', height: '34px', borderRadius: '50%',
          background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(6px)',
          border: '1px solid rgba(201,169,110,0.35)',
          color: 'var(--gold)', fontSize: '15px', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} title="Remove from wishlist">
          {removing ? '…' : '♥'}
        </button>
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '50px', background: 'linear-gradient(to top, var(--obsidian-2), transparent)' }} />
      </div>

      {/* Content */}
      <div style={{ padding: '16px 18px 18px' }}>
        <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px', fontWeight: 400, marginBottom: '4px', lineHeight: 1.2 }}>
          {hotel.name}
        </h3>
        <p style={{ fontSize: '13px', color: 'var(--muted)', marginBottom: '12px' }}>◎ {hotel.city}</p>
        {hotel.amenities?.length > 0 && (
          <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap', marginBottom: '12px' }}>
            {hotel.amenities.slice(0, 3).map(a => (
              <span key={a} style={{ fontSize: '11px', color: 'var(--muted)', background: 'var(--glass)', border: '1px solid var(--glass-border)', borderRadius: '4px', padding: '2px 6px' }}>{a}</span>
            ))}
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          {hotel.avgPrice != null && (
            <div>
              <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '22px', color: 'var(--gold)' }}>${Number(hotel.avgPrice).toFixed(0)}</span>
              <span style={{ fontSize: '11px', color: 'var(--muted)' }}>/night</span>
            </div>
          )}
          <span style={{ fontSize: '12px', color: 'var(--gold)' }}>View →</span>
        </div>
      </div>
    </div>
  );
}

export default function WishlistPage({ setPage, setSelectedHotel }) {
  const { isLoggedIn } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoggedIn) { setLoading(false); return; }
    getWishlist()
      .then(data => setItems(Array.isArray(data) ? data : data.content || []))
      .catch(() => setItems(getMockWishlist()))
      .finally(() => setLoading(false));
  }, [isLoggedIn]);

  const handleRemove = async (hotelId) => {
    await removeFromWishlist(hotelId);
    setItems(prev => prev.filter(h => h.id !== hotelId));
  };

  const handleSelect = (hotel) => {
    setSelectedHotel(hotel);
    setPage('hotel-detail');
  };

  if (!isLoggedIn) return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '100px 20px' }}>
      <div style={{ textAlign: 'center', maxWidth: '360px' }}>
        <div style={{ fontSize: '44px', marginBottom: '14px', color: 'var(--gold)', opacity: 0.6 }}>♥</div>
        <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: '28px', fontWeight: 300, marginBottom: '10px' }}>Your Wishlist</h2>
        <p style={{ color: 'var(--muted)', fontSize: '14px', marginBottom: '24px' }}>Sign in to view your saved hotels.</p>
        <Button onClick={() => setPage('auth')}>Sign In</Button>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: 'clamp(24px,5vw,48px) 20px' }}>
        <div style={{ marginBottom: '32px' }}>
          <GoldLine />
          <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(32px,6vw,48px)', fontWeight: 300, marginBottom: '6px' }}>
            Saved Hotels
          </h1>
          <p style={{ color: 'var(--muted)', fontSize: '13px' }}>
            {items.length} propert{items.length !== 1 ? 'ies' : 'y'} saved
          </p>
        </div>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}><Spinner size={36} /></div>
        ) : items.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '52px', opacity: 0.15, marginBottom: '14px' }}>♥</div>
            <p style={{ fontFamily: 'Cormorant Garamond', fontSize: '22px', marginBottom: '6px' }}>Nothing saved yet</p>
            <p style={{ fontSize: '13px', marginBottom: '20px' }}>Tap ♡ on any hotel to save it here.</p>
            <Button onClick={() => setPage('search')}>Browse Hotels</Button>
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(min(280px,100%), 1fr))',
            gap: '20px',
          }}>
            {items.map((hotel, i) => (
              <div key={hotel.id || i} className="fade-up" style={{ animationDelay: `${Math.min(i*0.06,0.3)}s` }}>
                <WishlistCard hotel={hotel} onRemove={handleRemove} onSelect={handleSelect} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function getMockWishlist() {
  return [
    { id: 1, name: 'Grand Maison', city: 'Paris', amenities: ['Pool', 'Spa', 'Restaurant'], avgPrice: 320 },
    { id: 3, name: 'The Meridian', city: 'Kyoto', amenities: ['Pool', 'Free WiFi'], avgPrice: 450 },
    { id: 5, name: 'Hôtel du Lac', city: 'Geneva', amenities: ['Restaurant', 'Pool', 'Gym'], avgPrice: 510 },
  ];
}
