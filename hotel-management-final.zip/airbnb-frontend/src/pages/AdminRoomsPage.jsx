import { useState, useEffect } from 'react';
import { createRoom, getAllRooms, deleteRoom } from '../services/api.js';
import { Button, Input, Badge, Modal, Spinner, GoldLine } from '../components/ui/index.jsx';

function RoomForm({ hotelId, onSave, onClose }) {
  const [form, setForm] = useState({
    type: '', basePrice: '', totalCount: 1, capacity: 2, amenities: '',
  });
  const [loading, setLoading] = useState(false);
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const payload = {
        ...form,
        basePrice: parseFloat(form.basePrice),
        totalCount: parseInt(form.totalCount),
        capacity: parseInt(form.capacity),
        amenities: form.amenities.split(',').map(s => s.trim()).filter(Boolean),
      };
      await onSave(payload);
      onClose();
    } catch (e) { alert(e.message); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Input label="Room Type" placeholder="Deluxe Suite" value={form.type} onChange={e => set('type', e.target.value)} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px' }}>
        <Input label="Base Price ($/night)" type="number" min={0} step="0.01" placeholder="299.00" value={form.basePrice} onChange={e => set('basePrice', e.target.value)} />
        <Input label="Total Rooms" type="number" min={1} value={form.totalCount} onChange={e => set('totalCount', e.target.value)} />
        <Input label="Capacity (guests)" type="number" min={1} value={form.capacity} onChange={e => set('capacity', e.target.value)} />
      </div>
      <Input label="Amenities (comma-separated)" placeholder="King Bed, Ocean View, Minibar" value={form.amenities} onChange={e => set('amenities', e.target.value)} />
      <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', paddingTop: '4px' }}>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} loading={loading}>Create Room</Button>
      </div>
    </div>
  );
}

export default function AdminRoomsPage({ hotel, setPage }) {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [deleting, setDeleting] = useState(null);

  useEffect(() => {
    getAllRooms(hotel.id)
      .then(setRooms)
      .catch(() => setRooms(getMockRooms()))
      .finally(() => setLoading(false));
  }, [hotel.id]);

  const handleCreate = async (data) => {
    try {
      const room = await createRoom(hotel.id, data);
      setRooms(r => [...r, { ...room, id: room.id || Date.now() }]);
    } catch {
      setRooms(r => [...r, { ...data, id: Date.now() }]);
    }
  };

  const handleDelete = async (room) => {
    setDeleting(room.id);
    try { await deleteRoom(hotel.id, room.id); } catch {}
    setRooms(r => r.filter(x => x.id !== room.id));
    setConfirmDelete(null);
    setDeleting(null);
  };

  const roomTypeColors = {
    'Suite': 'var(--gold)',
    'Deluxe': '#b8c6db',
    'Standard': 'var(--muted)',
    'Studio': '#a8d8ea',
    'Villa': '#f3a683',
  };
  const getRoomColor = (type) => {
    const key = Object.keys(roomTypeColors).find(k => type?.includes(k));
    return roomTypeColors[key] || 'var(--muted)';
  };

  return (
    <div style={{ minHeight: '100vh', paddingTop: '68px' }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '48px 40px' }}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '40px' }}>
          <div>
            <button onClick={() => setPage('admin-hotels')} style={{
              background: 'none', border: 'none', color: 'var(--muted)',
              fontSize: '13px', letterSpacing: '0.08em', cursor: 'pointer',
              marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '6px',
            }}>← Hotel Management</button>
            <GoldLine />
            <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: '44px', fontWeight: 300 }}>
              {hotel.name}
            </h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginTop: '6px' }}>
              <span style={{ color: 'var(--muted)', fontSize: '14px' }}>◎ {hotel.city}</span>
              {hotel.active
                ? <Badge variant="success">Active</Badge>
                : <Badge variant="muted">Inactive</Badge>
              }
              <span style={{ color: 'var(--muted)', fontSize: '13px' }}>{rooms.length} room types</span>
            </div>
          </div>
          <Button onClick={() => setShowCreate(true)}>+ Add Room Type</Button>
        </div>

        {/* Room stats */}
        {rooms.length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '32px' }}>
            {[
              { label: 'Room Types', val: rooms.length },
              { label: 'Total Inventory', val: rooms.reduce((s, r) => s + (r.totalCount || 0), 0) },
              { label: 'Max Capacity', val: rooms.reduce((s, r) => s + (r.capacity * r.totalCount || 0), 0) + ' guests' },
              { label: 'Avg Base Price', val: '$' + (rooms.reduce((s, r) => s + Number(r.basePrice || 0), 0) / rooms.length).toFixed(0) },
            ].map(stat => (
              <div key={stat.label} style={{
                background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
                borderRadius: 'var(--radius)', padding: '16px 18px',
              }}>
                <div style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '6px' }}>{stat.label}</div>
                <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '28px', color: 'var(--cream)' }}>{stat.val}</div>
              </div>
            ))}
          </div>
        )}

        {/* Rooms list */}
        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '80px 0' }}><Spinner size={36} /></div>
        ) : rooms.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '80px 0', color: 'var(--muted)' }}>
            <div style={{ fontSize: '48px', opacity: 0.2, marginBottom: '16px' }}>◇</div>
            <p style={{ fontFamily: 'Cormorant Garamond', fontSize: '22px' }}>No room types yet</p>
            <Button onClick={() => setShowCreate(true)} style={{ marginTop: '20px' }}>Add first room type</Button>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '20px' }}>
            {rooms.map(room => (
              <div key={room.id} style={{
                background: 'var(--obsidian-2)',
                border: '1px solid var(--glass-border)',
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                transition: 'all 0.25s',
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(201,169,110,0.2)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--glass-border)'; e.currentTarget.style.transform = 'none'; }}
              >
                {/* Color bar */}
                <div style={{ height: '3px', background: `linear-gradient(90deg, ${getRoomColor(room.type)}, transparent)` }} />

                <div style={{ padding: '20px 22px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '14px' }}>
                    <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '22px' }}>{room.type}</h3>
                    <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '24px', color: 'var(--gold)', textAlign: 'right' }}>
                      ${Number(room.basePrice).toFixed(0)}
                      <div style={{ fontSize: '11px', color: 'var(--muted)', fontFamily: 'DM Sans' }}>per night</div>
                    </div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '14px' }}>
                    {[
                      { icon: '◈', label: 'Inventory', val: `${room.totalCount} rooms` },
                      { icon: '◇', label: 'Capacity', val: `${room.capacity} guests` },
                    ].map(s => (
                      <div key={s.label} style={{ background: 'var(--glass)', borderRadius: '8px', padding: '10px 12px' }}>
                        <div style={{ fontSize: '10px', color: 'var(--muted)', letterSpacing: '0.08em', marginBottom: '2px' }}>{s.icon} {s.label}</div>
                        <div style={{ fontSize: '14px' }}>{s.val}</div>
                      </div>
                    ))}
                  </div>

                  {room.amenities?.length > 0 && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '14px' }}>
                      {room.amenities.map(a => (
                        <span key={a} style={{ fontSize: '11px', padding: '3px 8px', background: 'var(--gold-dim)', border: '1px solid rgba(201,169,110,0.15)', borderRadius: '4px', color: 'var(--gold)' }}>{a}</span>
                      ))}
                    </div>
                  )}

                  <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <button onClick={() => setConfirmDelete(room)} style={{
                      background: 'none', border: 'none', color: 'rgba(224,82,82,0.6)',
                      fontSize: '12px', cursor: 'pointer', padding: '4px 0',
                      transition: 'color 0.2s',
                    }}
                      onMouseEnter={e => e.target.style.color = 'var(--danger)'}
                      onMouseLeave={e => e.target.style.color = 'rgba(224,82,82,0.6)'}
                    >Delete room type</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal open={showCreate} onClose={() => setShowCreate(false)} title="Add Room Type">
        <RoomForm hotelId={hotel.id} onSave={handleCreate} onClose={() => setShowCreate(false)} />
      </Modal>

      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Room Type" width={420}>
        <p style={{ color: 'var(--muted)', marginBottom: '24px', lineHeight: 1.6 }}>
          Delete <strong style={{ color: 'var(--cream)' }}>{confirmDelete?.type}</strong>?
          All inventory records for this room type will also be permanently removed.
        </p>
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
          <Button variant="ghost" onClick={() => setConfirmDelete(null)}>Cancel</Button>
          <Button variant="danger" loading={deleting === confirmDelete?.id}
            onClick={() => handleDelete(confirmDelete)}>Delete Room</Button>
        </div>
      </Modal>
    </div>
  );
}

function getMockRooms() {
  return [
    { id: 1, type: 'Deluxe Suite', basePrice: 320, totalCount: 5, capacity: 2, amenities: ['King Bed', 'Ocean View', 'Minibar'] },
    { id: 2, type: 'Premium Double', basePrice: 195, totalCount: 10, capacity: 2, amenities: ['Queen Bed', 'Garden View'] },
    { id: 3, type: 'Executive Studio', basePrice: 450, totalCount: 3, capacity: 4, amenities: ['2 Beds', 'Terrace', 'Kitchenette'] },
  ];
}
