import { useState, useEffect } from 'react';
import { getHotelInfo, getHotelReviews, submitReview, addToWishlist, removeFromWishlist, getWishlist } from '../services/api.js';
import { Button, Badge, Spinner, GoldLine, Modal } from '../components/ui/index.jsx';
import { useAuth } from '../context/AuthContext.jsx';

function Stars({ rating, size = 14 }) {
  const r = Math.round(Number(rating) || 0);
  return (
    <span style={{ display: 'inline-flex', gap: '2px' }}>
      {[1,2,3,4,5].map(s => (
        <span key={s} style={{ fontSize: size, color: s <= r ? 'var(--gold)' : 'rgba(201,169,110,0.2)' }}>★</span>
      ))}
    </span>
  );
}

function ReviewCard({ review }) {
  const date = review.createdAt
    ? new Date(review.createdAt).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })
    : '';
  return (
    <div style={{
      background: 'var(--obsidian-3)', border: '1px solid var(--glass-border)',
      borderRadius: 'var(--radius)', padding: '16px 18px',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px', gap: '12px' }}>
        <div>
          <div style={{ fontWeight: 500, fontSize: '14px', marginBottom: '4px' }}>
            {review.userName || review.user?.name || 'Guest'}
          </div>
          <Stars rating={review.rating} />
        </div>
        <span style={{ fontSize: '11px', color: 'var(--muted)', flexShrink: 0 }}>{date}</span>
      </div>
      <p style={{ fontSize: '14px', color: 'rgba(245,240,232,0.75)', lineHeight: 1.7 }}>{review.comment}</p>
    </div>
  );
}

function WriteReviewModal({ open, onClose, onSubmit }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [hovered, setHovered] = useState(0);
  const [err, setErr] = useState('');

  const handleSubmit = async () => {
    if (!comment.trim()) { setErr('Please write a comment.'); return; }
    setLoading(true); setErr('');
    try {
      await onSubmit({ rating, comment });
      setComment(''); setRating(5);
      onClose();
    } catch (e) { setErr(e.message); }
    finally { setLoading(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title="Share Your Experience">
      <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
        <div>
          <label style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', display: 'block', marginBottom: '10px' }}>
            Rating
          </label>
          <div style={{ display: 'flex', gap: '4px', alignItems: 'center', flexWrap: 'wrap' }}>
            {[1,2,3,4,5].map(s => (
              <button key={s}
                onMouseEnter={() => setHovered(s)} onMouseLeave={() => setHovered(0)}
                onClick={() => setRating(s)}
                style={{
                  background: 'none', border: 'none', cursor: 'pointer', fontSize: '28px',
                  transition: 'transform 0.15s',
                  transform: (hovered || rating) >= s ? 'scale(1.2)' : 'scale(1)',
                  color: (hovered || rating) >= s ? 'var(--gold)' : 'rgba(201,169,110,0.2)',
                  padding: '2px',
                }}>★</button>
            ))}
            <span style={{ marginLeft: '6px', color: 'var(--muted)', fontSize: '13px' }}>
              {['','Poor','Fair','Good','Great','Excellent'][hovered || rating]}
            </span>
          </div>
        </div>
        <div>
          <label style={{ fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', display: 'block', marginBottom: '8px' }}>
            Your Review
          </label>
          <textarea value={comment} onChange={e => setComment(e.target.value)}
            placeholder="Tell future guests what made your stay special..."
            rows={4}
            style={{
              width: '100%', padding: '11px 13px',
              background: 'var(--obsidian-3)', border: '1px solid var(--glass-border)',
              borderRadius: 'var(--radius)', color: 'var(--cream)', fontSize: '14px',
              outline: 'none', resize: 'vertical', fontFamily: 'inherit', lineHeight: 1.6,
            }} />
          {err && <div style={{ fontSize: '12px', color: 'var(--danger)', marginTop: '4px' }}>{err}</div>}
        </div>
        <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} loading={loading} disabled={!comment.trim()}>Post Review</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function HotelDetailPage({ hotel, setPage, setBookingContext }) {
  const { isLoggedIn } = useAuth();
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activePhoto, setActivePhoto] = useState(0);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [wishlisted, setWishlisted] = useState(false);
  const [wishlistLoading, setWishlistLoading] = useState(false);
  const [wishMsg, setWishMsg] = useState('');

  useEffect(() => {
    window.scrollTo(0, 0);

    getHotelInfo(hotel.id)
      .then(setInfo)
      .catch(() => setInfo({ hotel, rooms: getMockRooms() }))
      .finally(() => setLoading(false));

    getHotelReviews(hotel.id)
      .then(data => setReviews(Array.isArray(data) ? data : data.content || []))
      .catch(() => setReviews(getMockReviews()))
      .finally(() => setReviewsLoading(false));

    if (isLoggedIn) {
      getWishlist()
        .then(data => {
          const list = Array.isArray(data) ? data : data.content || [];
          setWishlisted(list.some(h => h.id === hotel.id));
        })
        .catch(() => {});
    }
  }, [hotel.id]);

  const handleBook = () => {
    if (!isLoggedIn) { setPage('auth'); return; }
    if (!selectedRoom) return;
    setBookingContext({ hotel: info?.hotel || hotel, room: selectedRoom });
    setPage('booking');
  };

  const handleWishlist = async () => {
    if (!isLoggedIn) { setPage('auth'); return; }
    setWishlistLoading(true);
    try {
      if (wishlisted) {
        await removeFromWishlist(hotel.id);
        setWishlisted(false);
        setWishMsg('Removed from saved hotels');
      } else {
        await addToWishlist(hotel.id);
        setWishlisted(true);
        setWishMsg('Saved to wishlist!');
      }
      setTimeout(() => setWishMsg(''), 2000);
    } catch (e) { setWishMsg(e.message); }
    finally { setWishlistLoading(false); }
  };

  const handleReviewSubmit = async (data) => {
    await submitReview(hotel.id, data);
    const fresh = await getHotelReviews(hotel.id).catch(() => null);
    if (fresh) setReviews(Array.isArray(fresh) ? fresh : fresh.content || []);
  };

  if (loading) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', paddingTop: 'var(--nav-h)' }}>
      <Spinner size={40} />
    </div>
  );

  const h = info?.hotel || hotel;
  const rooms = info?.rooms || [];
  const photos = h.photos?.length ? h.photos : [];
  const avgRating = reviews.length
    ? (reviews.reduce((s, r) => s + (Number(r.rating) || 0), 0) / reviews.length).toFixed(1)
    : null;

  return (
    <div style={{ minHeight: '100vh', paddingTop: 'var(--nav-h)' }}>
      {/* Back button */}
      <div style={{ padding: '16px 20px', maxWidth: '1100px', margin: '0 auto' }}>
        <button onClick={() => setPage('search')} style={{
          background: 'none', border: 'none', color: 'var(--muted)',
          fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px',
          padding: '4px 0',
        }}>← Back to results</button>
      </div>

      {/* Photo */}
      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '0 20px' }}>
        <div style={{
          borderRadius: 'var(--radius-lg)', overflow: 'hidden',
          height: 'clamp(220px, 40vw, 420px)',
          background: 'var(--obsidian-3)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative',
        }}>
          {photos[activePhoto]
            ? <img src={photos[activePhoto]} alt={h.name}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : (
              <div style={{ textAlign: 'center', color: 'var(--muted)' }}>
                <div style={{ fontSize: '48px', opacity: 0.12, marginBottom: '10px' }}>◈</div>
                <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px', opacity: 0.3 }}>{h.name}</div>
              </div>
            )
          }

          {/* Gradient + info overlay */}
          <div style={{
            position: 'absolute', bottom: 0, left: 0, right: 0,
            height: '55%',
            background: 'linear-gradient(to top, rgba(10,10,15,0.9) 0%, transparent 100%)',
          }} />
          <div style={{ position: 'absolute', bottom: '20px', left: '20px', right: '60px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px', flexWrap: 'wrap' }}>
              {h.active ? <Badge variant="success">Available</Badge> : <Badge variant="muted">Unavailable</Badge>}
              {avgRating && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px', background: 'rgba(0,0,0,0.5)', padding: '3px 9px', borderRadius: '20px' }}>
                  <Stars rating={avgRating} size={11} />
                  <span style={{ fontSize: '12px', color: 'var(--gold)' }}>{avgRating}</span>
                  <span style={{ fontSize: '11px', color: 'var(--muted)' }}>({reviews.length})</span>
                </div>
              )}
            </div>
            <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(26px,5vw,44px)', fontWeight: 300, lineHeight: 1.1, textShadow: '0 2px 20px rgba(0,0,0,0.8)' }}>
              {h.name}
            </h1>
            <p style={{ color: 'rgba(245,240,232,0.75)', fontSize: '14px', marginTop: '4px' }}>
              ◎ {h.city}
            </p>
          </div>

          {/* Wishlist button */}
          <button onClick={handleWishlist} style={{
            position: 'absolute', top: '14px', right: '14px',
            width: '40px', height: '40px', borderRadius: '50%',
            background: wishlisted ? 'rgba(201,169,110,0.25)' : 'rgba(10,10,15,0.65)',
            backdropFilter: 'blur(8px)',
            border: `1px solid ${wishlisted ? 'rgba(201,169,110,0.5)' : 'rgba(255,255,255,0.15)'}`,
            color: wishlisted ? 'var(--gold)' : 'white',
            fontSize: '18px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {wishlistLoading ? '…' : wishlisted ? '♥' : '♡'}
          </button>

          {/* Photo dots */}
          {photos.length > 1 && (
            <div style={{ position: 'absolute', bottom: '14px', right: '14px', display: 'flex', gap: '5px' }}>
              {photos.map((_, i) => (
                <button key={i} onClick={() => setActivePhoto(i)} style={{
                  width: 7, height: 7, borderRadius: '50%', border: 'none', cursor: 'pointer',
                  background: i === activePhoto ? 'var(--gold)' : 'rgba(255,255,255,0.35)',
                  padding: 0,
                }} />
              ))}
            </div>
          )}
        </div>
        {wishMsg && (
          <div style={{ fontSize: '13px', color: 'var(--gold)', textAlign: 'right', marginTop: '6px' }}>
            {wishMsg}
          </div>
        )}
      </div>

      {/* Main content — two-column on desktop, stacked on mobile */}
      <div
        className="detail-grid"
        style={{
          maxWidth: '1100px', margin: '0 auto',
          padding: '32px 20px',
          display: 'grid',
          gridTemplateColumns: '1fr 320px',
          gap: '32px',
          alignItems: 'start',
        }}
      >
        {/* LEFT: Info + Rooms + Reviews */}
        <div>
          {/* Contact info */}
          {h.contactInfo && (
            <section style={{ marginBottom: '36px' }}>
              <GoldLine />
              <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(22px,4vw,30px)', marginBottom: '16px' }}>About this Property</h2>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px,1fr))', gap: '10px' }}>
                {[
                  { icon: '◎', label: 'Address',  val: h.contactInfo.address },
                  { icon: '◌', label: 'Phone',    val: h.contactInfo.phoneNumber },
                  { icon: '◉', label: 'Email',    val: h.contactInfo.email },
                  { icon: '◇', label: 'Location', val: h.contactInfo.location },
                ].filter(f => f.val).map(f => (
                  <div key={f.label} style={{
                    background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
                    borderRadius: 'var(--radius)', padding: '12px 14px',
                  }}>
                    <div style={{ fontSize: '10px', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '3px' }}>{f.icon} {f.label}</div>
                    <div style={{ fontSize: '13px', wordBreak: 'break-word' }}>{f.val}</div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Amenities */}
          {h.amenities?.length > 0 && (
            <section style={{ marginBottom: '36px' }}>
              <GoldLine />
              <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(22px,4vw,30px)', marginBottom: '16px' }}>Amenities</h2>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {h.amenities.map(a => (
                  <span key={a} style={{
                    padding: '7px 14px', borderRadius: '6px',
                    background: 'var(--gold-dim)', border: '1px solid rgba(201,169,110,0.2)',
                    color: 'var(--gold)', fontSize: '13px',
                  }}>✦ {a}</span>
                ))}
              </div>
            </section>
          )}

          {/* Rooms */}
          <section style={{ marginBottom: '36px' }}>
            <GoldLine />
            <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(22px,4vw,30px)', marginBottom: '16px' }}>Available Rooms</h2>
            {rooms.length === 0 ? (
              <p style={{ color: 'var(--muted)', fontSize: '14px' }}>No rooms listed yet.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {rooms.map(room => {
                  const sel = selectedRoom?.id === room.id;
                  return (
                    <div key={room.id} onClick={() => setSelectedRoom(sel ? null : room)}
                      style={{
                        background: sel ? 'rgba(201,169,110,0.06)' : 'var(--obsidian-2)',
                        border: `1px solid ${sel ? 'rgba(201,169,110,0.45)' : 'var(--glass-border)'}`,
                        borderRadius: 'var(--radius-lg)', padding: '16px 18px',
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        cursor: 'pointer', transition: 'all 0.2s', gap: '12px',
                      }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px', flexWrap: 'wrap' }}>
                          <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '20px' }}>{room.type}</h3>
                          {sel && <Badge variant="gold">Selected</Badge>}
                        </div>
                        <div style={{ display: 'flex', gap: '14px', color: 'var(--muted)', fontSize: '12px', flexWrap: 'wrap' }}>
                          <span>◈ {room.totalCount} rooms</span>
                          <span>◇ Up to {room.capacity} guests</span>
                        </div>
                        {room.amenities?.length > 0 && (
                          <div style={{ marginTop: '8px', display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                            {room.amenities.slice(0, 3).map(a => (
                              <span key={a} style={{ fontSize: '11px', color: 'var(--muted)', background: 'var(--glass)', border: '1px solid var(--glass-border)', borderRadius: '4px', padding: '2px 7px' }}>{a}</span>
                            ))}
                          </div>
                        )}
                      </div>
                      <div style={{ textAlign: 'right', flexShrink: 0 }}>
                        <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '26px', color: 'var(--gold)' }}>
                          ${Number(room.basePrice).toFixed(0)}
                        </div>
                        <div style={{ fontSize: '11px', color: 'var(--muted)' }}>/night</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Reviews */}
          <section>
            <GoldLine />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px', gap: '12px' }}>
              <div>
                <h2 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(22px,4vw,30px)' }}>Guest Reviews</h2>
                {avgRating && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '7px', marginTop: '5px' }}>
                    <Stars rating={avgRating} size={14} />
                    <span style={{ fontFamily: 'Cormorant Garamond', fontSize: '18px', color: 'var(--gold)' }}>{avgRating}</span>
                    <span style={{ color: 'var(--muted)', fontSize: '12px' }}>· {reviews.length} review{reviews.length !== 1 ? 's' : ''}</span>
                  </div>
                )}
              </div>
              {isLoggedIn && (
                <Button variant="outline" size="sm" onClick={() => setShowReviewModal(true)}>
                  Write Review
                </Button>
              )}
            </div>

            {reviewsLoading ? (
              <div style={{ display: 'flex', justifyContent: 'center', padding: '32px 0' }}><Spinner /></div>
            ) : reviews.length === 0 ? (
              <div style={{
                textAlign: 'center', padding: '32px', background: 'var(--obsidian-2)',
                borderRadius: 'var(--radius-lg)', border: '1px solid var(--glass-border)',
              }}>
                <div style={{ fontSize: '32px', opacity: 0.15, marginBottom: '10px' }}>★</div>
                <p style={{ color: 'var(--muted)', fontSize: '14px' }}>
                  No reviews yet.{' '}
                  {isLoggedIn
                    ? <button onClick={() => setShowReviewModal(true)} style={{ background: 'none', border: 'none', color: 'var(--gold)', cursor: 'pointer', fontSize: '14px' }}>Be the first!</button>
                    : 'Sign in to write a review.'
                  }
                </p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {reviews.map((r, i) => <ReviewCard key={r.id || i} review={r} />)}
              </div>
            )}
          </section>
        </div>

        {/* RIGHT: Booking sidebar */}
        <div className="detail-sidebar" style={{ position: 'sticky', top: 'calc(var(--nav-h) + 20px)' }}>
          <div style={{
            background: 'var(--obsidian-2)', border: '1px solid var(--glass-border)',
            borderRadius: 'var(--radius-lg)', padding: '24px',
            boxShadow: '0 8px 40px rgba(0,0,0,0.4)',
          }}>
            <h3 style={{ fontFamily: 'Cormorant Garamond', fontSize: '24px', marginBottom: '4px' }}>Reserve Your Stay</h3>
            <GoldLine />

            {selectedRoom ? (
              <div style={{ marginTop: '16px' }}>
                <div style={{
                  background: 'var(--gold-dim)', border: '1px solid rgba(201,169,110,0.2)',
                  borderRadius: 'var(--radius)', padding: '14px', marginBottom: '16px',
                }}>
                  <div style={{ fontSize: '10px', color: 'var(--muted)', letterSpacing: '0.1em', marginBottom: '3px' }}>SELECTED</div>
                  <div style={{ fontFamily: 'Cormorant Garamond', fontSize: '18px' }}>{selectedRoom.type}</div>
                  <div style={{ color: 'var(--gold)', fontFamily: 'Cormorant Garamond', fontSize: '22px', marginTop: '2px' }}>
                    ${Number(selectedRoom.basePrice).toFixed(0)}<span style={{ fontSize: '12px', color: 'var(--muted)' }}>/night</span>
                  </div>
                </div>
                <Button size="lg" onClick={handleBook} style={{ width: '100%' }}>
                  ✦ Book This Room
                </Button>
                {!isLoggedIn && (
                  <p style={{ fontSize: '11px', color: 'var(--muted)', textAlign: 'center', marginTop: '8px' }}>
                    You'll be asked to sign in
                  </p>
                )}
              </div>
            ) : (
              <div style={{ marginTop: '16px', textAlign: 'center', color: 'var(--muted)', padding: '20px 0' }}>
                <div style={{ fontSize: '28px', opacity: 0.2, marginBottom: '10px' }}>◇</div>
                <p style={{ fontSize: '13px' }}>Select a room from the list</p>
              </div>
            )}

            {/* Wishlist CTA */}
            <button onClick={handleWishlist} style={{
              width: '100%', marginTop: '12px', padding: '10px',
              background: wishlisted ? 'var(--gold-dim)' : 'var(--glass)',
              border: `1px solid ${wishlisted ? 'rgba(201,169,110,0.3)' : 'var(--glass-border)'}`,
              borderRadius: 'var(--radius)',
              color: wishlisted ? 'var(--gold)' : 'var(--muted)',
              fontSize: '13px', cursor: 'pointer', fontFamily: 'inherit',
              transition: 'all 0.2s',
            }}>
              {wishlisted ? '♥ Saved to Wishlist' : '♡ Save to Wishlist'}
            </button>

            <div style={{ marginTop: '18px', borderTop: '1px solid var(--glass-border)', paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '7px' }}>
              {['✦ Instant confirmation', '✦ Free cancellation available', '✦ Secure payment'].map(t => (
                <div key={t} style={{ fontSize: '12px', color: 'var(--muted)' }}>{t}</div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <WriteReviewModal
        open={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        onSubmit={handleReviewSubmit}
      />

      {/* Responsive grid override */}
      <style>{`
        @media (max-width: 768px) {
          .detail-grid { grid-template-columns: 1fr !important; }
          .detail-sidebar { position: static !important; }
        }
      `}</style>
    </div>
  );
}

function getMockRooms() {
  return [
    { id: 1, type: 'Deluxe Suite', basePrice: 320, totalCount: 5, capacity: 2, amenities: ['King Bed', 'Ocean View', 'Minibar'] },
    { id: 2, type: 'Premium Double', basePrice: 195, totalCount: 10, capacity: 2, amenities: ['Queen Bed', 'Garden View'] },
    { id: 3, type: 'Executive Studio', basePrice: 450, totalCount: 3, capacity: 4, amenities: ['2 Beds', 'Terrace', 'Kitchenette'] },
  ];
}

function getMockReviews() {
  return [
    { id: 1, userName: 'Sophie L.', rating: 5, comment: 'Absolutely stunning property. The staff were impeccable and the rooms exceeded every expectation.', createdAt: '2026-03-10' },
    { id: 2, userName: 'Marco R.', rating: 4, comment: 'Beautiful hotel with a wonderful atmosphere. The spa facilities were world-class.', createdAt: '2026-02-22' },
    { id: 3, userName: 'Priya K.', rating: 5, comment: 'One of the finest stays I have ever experienced. The attention to detail is remarkable.', createdAt: '2026-01-15' },
  ];
}
