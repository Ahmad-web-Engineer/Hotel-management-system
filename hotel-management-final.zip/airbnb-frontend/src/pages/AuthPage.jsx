import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { Button, Input, GoldLine } from '../components/ui/index.jsx';

export default function AuthPage({ setPage }) {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const switchMode = (m) => { setMode(m); setError(''); setSuccess(''); };

  const validate = () => {
    if (!form.email.trim()) return 'Email is required.';
    if (!/\S+@\S+\.\S+/.test(form.email)) return 'Enter a valid email address.';
    if (!form.password) return 'Password is required.';
    if (mode === 'register') {
      if (!form.name.trim()) return 'Full name is required.';
      if (form.password.length < 6) return 'Password must be at least 6 characters.';
      if (form.password !== form.confirmPassword) return 'Passwords do not match.';
    }
    return null;
  };

  const handleSubmit = async () => {
    const err = validate();
    if (err) { setError(err); return; }
    setLoading(true); setError(''); setSuccess('');
    try {
      if (mode === 'login') {
        await login({ email: form.email, password: form.password });
        setPage('home');
      } else {
        await register({ name: form.name, email: form.email, password: form.password });
        setSuccess('Account created! Redirecting…');
        setTimeout(() => setPage('home'), 1000);
      }
    } catch (e) {
      setError(e.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => { if (e.key === 'Enter' && !loading) handleSubmit(); };

  return (
    <div style={{
      minHeight: '100vh', paddingTop: 'var(--nav-h)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 'var(--nav-h) 16px 40px',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Background glow */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        background: `radial-gradient(ellipse 60% 60% at 50% 40%, rgba(201,169,110,0.05) 0%, transparent 70%)`,
      }} />

      <div className="fade-up" style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: '420px' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '48px', height: '48px', borderRadius: '12px',
            background: 'linear-gradient(135deg, var(--gold), #a8833e)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '20px', fontWeight: 700, color: '#0a0a0f',
            margin: '0 auto 16px',
          }}>H</div>
          <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: 'clamp(28px, 6vw, 38px)', fontWeight: 300, marginBottom: '6px' }}>
            {mode === 'login' ? 'Welcome Back' : 'Create Account'}
          </h1>
          <GoldLine style={{ margin: '10px auto' }} />
          <p style={{ color: 'var(--muted)', fontSize: '13px' }}>
            {mode === 'login'
              ? 'Sign in to manage your hotel bookings'
              : 'Register to start booking hotels'}
          </p>
        </div>

        {/* Card */}
        <div style={{
          background: 'var(--obsidian-2)',
          border: '1px solid var(--glass-border)',
          borderRadius: 'var(--radius-lg)',
          padding: 'clamp(20px, 5vw, 32px)',
          boxShadow: '0 24px 80px rgba(0,0,0,0.5)',
        }}>
          {/* Tabs */}
          <div style={{
            display: 'flex', background: 'var(--obsidian-3)',
            borderRadius: 'var(--radius)', padding: '3px', marginBottom: '24px',
          }}>
            {[['login','Sign In'], ['register','Register']].map(([m, label]) => (
              <button key={m} onClick={() => switchMode(m)} style={{
                flex: 1, padding: '8px', border: 'none', borderRadius: '8px',
                fontSize: '13px', letterSpacing: '0.05em', cursor: 'pointer',
                transition: 'all 0.2s', fontFamily: 'inherit',
                background: mode === m ? 'var(--obsidian-2)' : 'transparent',
                color: mode === m ? 'var(--cream)' : 'var(--muted)',
                boxShadow: mode === m ? '0 2px 8px rgba(0,0,0,0.4)' : 'none',
              }}>{label}</button>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {mode === 'register' && (
              <Input label="Full Name" icon="◇" placeholder="Your full name"
                value={form.name} onChange={e => set('name', e.target.value)} onKeyDown={handleKey}
                autoComplete="name" />
            )}
            <Input label="Email Address" icon="◉" type="email" placeholder="you@example.com"
              value={form.email} onChange={e => set('email', e.target.value)} onKeyDown={handleKey}
              autoComplete="email" />
            <Input label="Password" icon="◈" type="password" placeholder="••••••••"
              value={form.password} onChange={e => set('password', e.target.value)} onKeyDown={handleKey}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
            {mode === 'register' && (
              <Input label="Confirm Password" icon="◈" type="password" placeholder="••••••••"
                value={form.confirmPassword} onChange={e => set('confirmPassword', e.target.value)} onKeyDown={handleKey}
                autoComplete="new-password" />
            )}
          </div>

          {error && (
            <div style={{
              marginTop: '14px', padding: '11px 13px', borderRadius: 'var(--radius)',
              background: 'rgba(224,82,82,0.08)', border: '1px solid rgba(224,82,82,0.25)',
              fontSize: '13px', color: 'var(--danger)',
            }}>⚠ {error}</div>
          )}
          {success && (
            <div style={{
              marginTop: '14px', padding: '11px 13px', borderRadius: 'var(--radius)',
              background: 'rgba(82,196,126,0.08)', border: '1px solid rgba(82,196,126,0.25)',
              fontSize: '13px', color: 'var(--success)',
            }}>✓ {success}</div>
          )}

          <Button onClick={handleSubmit} loading={loading} size="lg"
            style={{ width: '100%', marginTop: '20px' }}>
            {mode === 'login' ? 'Sign In' : 'Create Account'}
          </Button>

          <button onClick={() => setPage('home')} style={{
            display: 'block', width: '100%', marginTop: '12px',
            background: 'none', border: 'none', color: 'var(--muted)',
            fontSize: '13px', cursor: 'pointer', padding: '8px',
          }}>← Back to Home</button>
        </div>
      </div>
    </div>
  );
}
