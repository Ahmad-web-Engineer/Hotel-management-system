import { useState } from 'react';
import './index.css';
import { AuthProvider } from './context/AuthContext.jsx';
import Navbar from './components/layout/Navbar.jsx';
import HomePage from './pages/HomePage.jsx';
import SearchPage from './pages/SearchPage.jsx';
import HotelDetailPage from './pages/HotelDetailPage.jsx';
import BookingPage from './pages/BookingPage.jsx';
import AdminHotelsPage from './pages/AdminHotelsPage.jsx';
import AdminRoomsPage from './pages/AdminRoomsPage.jsx';
import AuthPage from './pages/AuthPage.jsx';
import BookingHistoryPage from './pages/BookingHistoryPage.jsx';
import WishlistPage from './pages/WishlistPage.jsx';

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}

function AppInner() {
  const [page, setPage] = useState('home');
  const [isAdmin, setIsAdmin] = useState(false);

  const [searchParams, setSearchParams] = useState({});
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [bookingContext, setBookingContext] = useState(null);
  const [adminHotelContext, setAdminHotelContext] = useState(null);

  const renderPage = () => {
    switch (page) {
      case 'home':
        return <HomePage setPage={setPage} setSearchParams={setSearchParams} />;
      case 'search':
        return (
          <SearchPage
            initialParams={searchParams}
            setPage={setPage}
            setSelectedHotel={setSelectedHotel}
          />
        );
      case 'hotel-detail':
        return selectedHotel ? (
          <HotelDetailPage
            hotel={selectedHotel}
            setPage={setPage}
            setBookingContext={setBookingContext}
          />
        ) : null;
      case 'booking':
        return bookingContext ? (
          <BookingPage bookingContext={bookingContext} setPage={setPage} />
        ) : null;
      case 'admin-hotels':
        return (
          <AdminHotelsPage
            setPage={setPage}
            setAdminHotelContext={setAdminHotelContext}
          />
        );
      case 'admin-rooms':
        return adminHotelContext ? (
          <AdminRoomsPage hotel={adminHotelContext} setPage={setPage} />
        ) : null;
      case 'auth':
        return <AuthPage setPage={setPage} />;
      case 'bookings':
        return <BookingHistoryPage setPage={setPage} />;
      case 'wishlist':
        return (
          <WishlistPage
            setPage={setPage}
            setSelectedHotel={setSelectedHotel}
          />
        );
      case 'about':
        return <AboutPage setPage={setPage} />;
      default:
        return <HomePage setPage={setPage} setSearchParams={setSearchParams} />;
    }
  };

  return (
    <>
      <Navbar page={page} setPage={setPage} isAdmin={isAdmin} setIsAdmin={setIsAdmin} />
      <main>{renderPage()}</main>
    </>
  );
}

function AboutPage({ setPage }) {
  return (
    <div style={{ minHeight: '100vh', paddingTop: '68px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ maxWidth: '640px', padding: '80px 40px', textAlign: 'center' }}>
        <div style={{ width: '64px', height: '64px', borderRadius: '16px', background: 'linear-gradient(135deg, var(--gold), #a8833e)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28px', margin: '0 auto 28px' }}>✦</div>
        <h1 style={{ fontFamily: 'Cormorant Garamond', fontSize: '56px', fontWeight: 300, marginBottom: '20px' }}>About This System</h1>
        <div style={{ width: '40px', height: '2px', background: 'linear-gradient(90deg, var(--gold), transparent)', margin: '0 auto 24px' }} />
        <p style={{ color: 'var(--muted)', fontSize: '16px', lineHeight: 1.8, marginBottom: '20px' }}>
          A full-stack Hotel Management System for browsing, booking, and managing hotel stays. Designed for both guests and administrators.
        </p>
        <p style={{ color: 'var(--muted)', fontSize: '15px', lineHeight: 1.8, marginBottom: '40px' }}>
          Built on a Spring Boot backend with JWT authentication, role-based access control, dynamic pricing via InventoryService, and a full booking pipeline including guest management and booking history.
        </p>
        <button onClick={() => setPage('search')} style={{
          background: 'linear-gradient(135deg, var(--gold), #a8833e)',
          border: 'none', color: '#0a0a0f', padding: '14px 36px',
          borderRadius: 'var(--radius)', fontSize: '14px', cursor: 'pointer',
          fontFamily: 'DM Sans', letterSpacing: '0.04em',
        }}>Start Exploring</button>
      </div>
    </div>
  );
}
