# Vela — AirBnb Clone Frontend

A dark, premium React frontend for the AirBnb Clone Spring Boot backend.

## Tech Stack
- **React 18** + **Vite**
- Zero external UI libraries — fully custom component system
- Google Fonts: Cormorant Garamond + DM Sans
- CSS custom properties for full design token consistency

## Project Structure

```
src/
├── services/
│   └── api.js              # All backend API calls (maps 1:1 to your controllers)
├── components/
│   ├── ui/index.jsx         # Button, Input, Card, Badge, Modal, Spinner, etc.
│   └── layout/Navbar.jsx    # Top navigation
├── pages/
│   ├── HomePage.jsx         # Landing + hero search
│   ├── SearchPage.jsx       # Hotel search results (GET /hotels/search)
│   ├── HotelDetailPage.jsx  # Hotel info + room selection (GET /hotels/:id/info)
│   ├── BookingPage.jsx      # 3-step booking flow
│   │                          Step 1: POST /bookings/init
│   │                          Step 2: POST /bookings/:id/addGuests
│   │                          Step 3: Confirmation
│   ├── AdminHotelsPage.jsx  # CRUD /admin/hotels
│   └── AdminRoomsPage.jsx   # CRUD /admin/hotels/:id/rooms
└── App.jsx                  # Client-side router + shared state
```

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Configure API URL
cp .env.example .env.local
# Edit VITE_API_URL=http://localhost:8080

# 3. Run dev server
npm run dev
```

Your Spring Boot backend should be running on port 8080.

## API Mapping

| Frontend Action          | Backend Endpoint                          |
|--------------------------|-------------------------------------------|
| Hotel search             | POST /hotels/search                       |
| Hotel detail             | GET /hotels/{id}/info                     |
| Init booking             | POST /bookings/init                       |
| Add guests               | POST /bookings/{id}/addGuests             |
| Create hotel (admin)     | POST /admin/hotels                        |
| Update hotel (admin)     | PUT /admin/hotels/{id}                    |
| Delete hotel (admin)     | DELETE /admin/hotels/{id}                 |
| Activate hotel (admin)   | PATCH /admin/hotels/{id}                  |
| Create room (admin)      | POST /admin/hotels/{id}/rooms             |
| List rooms (admin)       | GET /admin/hotels/{id}/rooms              |
| Delete room (admin)      | DELETE /admin/hotels/{id}/rooms/{roomId}  |

## Notes
- The app gracefully falls back to mock/demo data when the backend is unavailable
- All API responses are expected to follow your `ApiResponse<T>` wrapper (`{ data, error, timeStamp }`)
- Add Spring Security + JWT to protect `/admin/*` routes and inject real user from `SecurityContextHolder`
- Set `VITE_API_URL` in production to your deployed backend URL
